"""Lab 2: Feature Engineering and Hidden Leakage (learner scaffold).

Check a step:   python run_lab.py --lab 2 --step N --script labs/lab2_leakage.py

Scenario: the data science team's quick baseline hit 99.8% accuracy. The slide deck for the CISO is ready.
Your job is to find out whether the number is real before it ships. The table they trained on is data/w1/lab2_table.pkl.
The enrichment code they used is pipeline_src/enrich.py. You may read it. You should.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs"):
    sys.path.insert(0, str(p))
from common import W1  # noqa: E402
import lab2_tools as T  # noqa: E402

state = {"df": pd.read_pickle(W1 / "lab2_table.pkl")}

POOL = ["duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "bytes_per_pkt", "payload_entropy", "orig_ttl",
        "host_alert_count_24h", "proto", "service", "conn_state", "history", "dst_port", "source_sensor", "ticket_id",
        "analyst_note", "cmdline_window"]

# ------------------------------------------------------------------ Step 1: the quick model
# A spec is {"numeric": [...], "categorical": {col: "onehot"|"ordinal"|"target"|"bucket_port"}, "text": [...]}.
# Start with everything in, the way the baseline did. Look at the number. Do not believe it yet.
state["spec"] = {
    "numeric": ["duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "bytes_per_pkt", "payload_entropy", "orig_ttl", "host_alert_count_24h"],
    "categorical": {"proto": "onehot", "service": "onehot", "conn_state": "onehot", "history": "onehot", "dst_port": "onehot", "source_sensor": "onehot", "ticket_id": "onehot"},
    "text": ["analyst_note", "cmdline_window"],
}
# print(T.quick_eval(state["df"], state["spec"], n_splits=3, n_estimators=60))

# ------------------------------------------------------------------ Step 2: label-shuffle test (mandatory before anything else)
# print(T.shuffle_test(state["df"], state["spec"]))

# ------------------------------------------------------------------ Step 3: investigate, then decide per feature
# Tools: T.feature_importance(df, spec), T.perm_importance(df, spec), T.label_rate(df, col), T.single_feature_auc(df, col),
#        T.ablation(df, spec), T.top_tfidf_tokens(df, col), and the source of pipeline_src/enrich.py.
# Importance ranking is not a leak detector. Ablation and per-category label rates are.
# Required: state["decisions"] = {col: {"action": "keep"|"drop"|"transform", "reason": "..."} for every col in POOL}
# Name the leak type in the reason: label, temporal, proxy, distribution artefact. Or explain why it is genuine signal.
state["decisions"] = {c: {"action": "keep", "reason": "TODO"} for c in POOL}

# ------------------------------------------------------------------ Step 4: encodings
# Rewrite state["spec"] with your surviving features and encodings. Encoders are fitted inside the pipeline by build_model.
# T.target_encode_full exists. Think about why it exists before you use it.

# ------------------------------------------------------------------ Step 5: the gate and the arithmetic
# The grader trains your spec on week 1 and scores it on a private week 2 (different red team, different tooling).
# Pick a threshold, get the confusion matrix from T.ppv_at_threshold on your OWN held-out fold, and compute PPV by hand.
state["threshold"] = 0.5
state["ppv_estimate"] = None   # your hand-computed PPV at that threshold, as a fraction
