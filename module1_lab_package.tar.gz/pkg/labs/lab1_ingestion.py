"""Lab 1: Data Ingestion Under Chaos (learner scaffold).

Fill in each step, then check it:   python run_lab.py --lab 1 --step N --script labs/lab1_ingestion.py
Every step reads and writes the `state` dict. The probe inspects `state`, not your code.

Scenario: three collectors and one ticketing export for Tuesday 08:00 to 14:00 UTC. Priya Nair, the SOC lead, wants one clean,
typed table of flows by end of day. Every row you cannot trace to a source is a row an attacker could have inserted.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from common import W1, FLOW_SCHEMA  # noqa: E402

state = {}

# ------------------------------------------------------------------ Step 1: load everything and watch it fail
# Sources: W1/"zeek_sensorA_conn.log" (Zeek TSV), W1/"zeek_sensorB_conn.jsonl" (Zeek JSON lines),
#          W1/"flows_export.csv" (exporter CSV), W1/"windows/*.evtx.xml" (python-evtx style record dumps).
# Required state keys: zeek_a, zeek_b, flows, windows  (all DataFrames)
# Contract: zeek columns keep Zeek names (id.orig_h ...) or the renamed src_ip/src_port/dst_ip/dst_port/proto;
#           windows must have columns host, event_id, system_time, and one column per EventData field (CommandLine, LogonType ...)
# Try pd.read_csv on everything first. Read the errors. Then do it properly.

# state["zeek_a"] = ...
# state["zeek_b"] = ...
# state["flows"] = pd.read_csv(W1 / "flows_export.csv", low_memory=False)
# state["windows"] = ...

# ------------------------------------------------------------------ Step 2: fix the schema
# Decisions: what to do with Infinity/NaN in 'Flow Bytes/s' and 'Flow Packets/s'; what to do with the doubled column.
# Required: state["flows"] has stripped column names, a zero_duration column, numeric rate columns, and the same row count.

# ------------------------------------------------------------------ Step 3: normalise timestamps
# Required: a tz-aware UTC column named ts_utc on zeek_a, zeek_b, flows and windows.
# Sensor-A ts is epoch seconds. Sensor-B ts is ISO 8601 with an offset. The export is 12-hour with no AM/PM marker.
# Windows SystemTime claims UTC. Verify that claim per host against the Zeek capture window.

# ------------------------------------------------------------------ Step 4: deduplicate
# Required: state["table"] with columns FLOW_SCHEMA (ts_utc, uid, src_ip, src_port, dst_ip, dst_port, proto, service, duration,
#           orig_bytes, resp_bytes, orig_pkts, resp_pkts, conn_state, history, source_sensor, source_file, row_hash).
# Both sensors saw the same tap for part of the network. Their uids differ. Their clocks differ by under a second.
# A host on 10.40.7.22 talks to 198.51.100.14:443 every 60 seconds. That is not a duplicate.
# Provenance on every row. When you merge two rows, the survivor must say which sensors saw it.

# state["table"] = ...

if __name__ == "__main__":
    print({k: getattr(v, "shape", v) for k, v in state.items()})
