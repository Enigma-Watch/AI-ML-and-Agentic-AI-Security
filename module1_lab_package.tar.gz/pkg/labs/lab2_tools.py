"""Lab 2 tools: build a quick model from a feature spec and interrogate it.

A feature spec is a dict:
  {"numeric": [...], "categorical": {"col": "onehot"|"ordinal"|"target"|"bucket_port"}, "text": [...]}
Encodings are fitted INSIDE the pipeline, so cross-validation is honest unless you sabotage it yourself
(see target_encode_full below, which is provided because people do exactly that).
"""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline, make_pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, OrdinalEncoder

ADMIN_PORTS = {22, 135, 139, 445, 3389, 5985, 5986, 1433, 5432}


class TargetMeanEncoder(BaseEstimator, TransformerMixin):
    """Smoothed target-mean encoding, fitted on the training fold only when used inside a Pipeline."""
    def __init__(self, smoothing=20):
        self.smoothing = smoothing

    def fit(self, X, y):
        X = pd.DataFrame(X); y = np.asarray(y)
        self.prior_ = y.mean(); self.maps_ = {}
        for c in X.columns:
            g = pd.DataFrame({"c": X[c].astype(str).values, "y": y}).groupby("c")["y"].agg(["sum", "count"])
            self.maps_[c] = ((g["sum"] + self.smoothing * self.prior_) / (g["count"] + self.smoothing)).to_dict()
        return self

    def transform(self, X):
        X = pd.DataFrame(X)
        return np.column_stack([X[c].astype(str).map(self.maps_[c]).fillna(self.prior_).values for c in X.columns])


def bucket_port(X):
    X = pd.DataFrame(X)
    out = []
    for c in X.columns:
        p = pd.to_numeric(X[c], errors="coerce").fillna(-1).astype(int)
        out.append(np.column_stack([(p < 1024).astype(int), ((p >= 1024) & (p < 49152)).astype(int), (p >= 49152).astype(int),
                                    p.isin(ADMIN_PORTS).astype(int)]))
    return np.hstack(out)


def target_encode_full(df, col, label="label", smoothing=1):
    """Writes a target-encoded column onto df using ALL rows. This is the leak. It is here so the probe can catch you."""
    prior = df[label].mean()
    g = df.groupby(col)[label].agg(["sum", "count"])
    m = (g["sum"] + smoothing * prior) / (g["count"] + smoothing)
    df[col + "_te"] = df[col].map(m).fillna(prior)
    return df


def make_column_transformer(spec):
    parts = []
    if spec.get("numeric"):
        parts.append(("num", SimpleImputer(strategy="median"), list(spec["numeric"])))
    for col, enc in spec.get("categorical", {}).items():
        if enc == "onehot":
            parts.append((f"oh_{col}", OneHotEncoder(handle_unknown="ignore", min_frequency=5), [col]))
        elif enc == "ordinal":
            parts.append((f"ord_{col}", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1), [col]))
        elif enc == "target":
            parts.append((f"te_{col}", TargetMeanEncoder(), [col]))
        elif enc == "bucket_port":
            parts.append((f"bp_{col}", FunctionTransformer(bucket_port, validate=False), [col]))
        else:
            raise ValueError(f"unknown encoding {enc} for {col}")
    for col in spec.get("text", []):
        parts.append((f"tf_{col}", make_pipeline(FunctionTransformer(lambda s: s.fillna("").astype(str).values.ravel(), validate=False),
                                                 TfidfVectorizer(max_features=200, token_pattern=r"[A-Za-z_\-\.]{3,}")), [col]))
    return ColumnTransformer(parts, sparse_threshold=0)


def build_model(spec, n_estimators=100, seed=0):
    return Pipeline([("features", make_column_transformer(spec)),
                     ("rf", RandomForestClassifier(n_estimators=n_estimators, n_jobs=-1, random_state=seed, class_weight="balanced", min_samples_leaf=2))])


def spec_columns(spec):
    return list(spec.get("numeric", [])) + list(spec.get("categorical", {})) + list(spec.get("text", []))


def quick_eval(df, spec, n_splits=5, seed=0, n_estimators=100):
    """Stratified random K-fold CV. Returns mean accuracy, ROC-AUC, PR-AUC."""
    X = df[spec_columns(spec)]; y = df["label"].values
    acc, roc, pr = [], [], []
    for tr, te in StratifiedKFold(n_splits, shuffle=True, random_state=seed).split(X, y):
        m = build_model(spec, n_estimators, seed).fit(X.iloc[tr], y[tr])
        p = m.predict_proba(X.iloc[te])[:, 1]
        acc.append(((p >= 0.5) == y[te]).mean()); roc.append(roc_auc_score(y[te], p)); pr.append(average_precision_score(y[te], p))
    return {"accuracy": float(np.mean(acc)), "roc_auc": float(np.mean(roc)), "pr_auc": float(np.mean(pr))}


def shuffle_test(df, spec, seed=0, n_estimators=60):
    d = df.copy()
    d["label"] = np.random.default_rng(seed).permutation(d["label"].values)
    return quick_eval(d, spec, n_splits=3, seed=seed, n_estimators=n_estimators)["pr_auc"]


def feature_importance(df, spec, seed=0):
    """RF impurity importance aggregated back to the original column names."""
    X = df[spec_columns(spec)]; y = df["label"].values
    m = build_model(spec, 100, seed).fit(X, y)
    ct = m.named_steps["features"]; imp = m.named_steps["rf"].feature_importances_
    agg = {}
    for name, sl in ct.output_indices_.items():
        if name == "num":
            for c, v in zip(spec["numeric"], imp[sl]):
                agg[c] = agg.get(c, 0) + float(v)
        elif name != "remainder":
            agg[name.split("_", 1)[1]] = float(imp[sl].sum())
    return pd.Series(agg).sort_values(ascending=False)


def perm_importance(df, spec, seed=0):
    X = df[spec_columns(spec)]; y = df["label"].values
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, stratify=y, random_state=seed)
    m = build_model(spec, 60, seed).fit(Xtr, ytr)
    r = permutation_importance(m, Xte, yte, scoring="average_precision", n_repeats=3, random_state=seed, n_jobs=1)
    return pd.Series(r.importances_mean, index=X.columns).sort_values(ascending=False)


def label_rate(df, col, top=15):
    g = df.groupby(col)["label"].agg(["mean", "count"]).sort_values("mean", ascending=False)
    return g.head(top)


def single_feature_auc(df, col):
    x = pd.to_numeric(df[col], errors="coerce").fillna(-1)
    a = roc_auc_score(df["label"], x)
    return float(max(a, 1 - a))


def ablation(df, spec, seed=0):
    """Drop one feature at a time, retrain, report PR-AUC delta. Slow; that is the price of an honest answer."""
    base = quick_eval(df, spec, n_splits=3, seed=seed, n_estimators=60)["pr_auc"]
    rows = []
    for col in spec_columns(spec):
        s = {"numeric": [c for c in spec.get("numeric", []) if c != col],
             "categorical": {k: v for k, v in spec.get("categorical", {}).items() if k != col},
             "text": [c for c in spec.get("text", []) if c != col]}
        pr = quick_eval(df, s, n_splits=3, seed=seed, n_estimators=60)["pr_auc"]
        rows.append({"dropped": col, "pr_auc": pr, "delta": base - pr})
    return pd.DataFrame(rows).sort_values("delta", ascending=False).reset_index(drop=True), base


def top_tfidf_tokens(df, col, k=12):
    v = TfidfVectorizer(max_features=500, token_pattern=r"[A-Za-z_\-\.]{3,}").fit(df[col].fillna(""))
    X = v.transform(df[col].fillna(""))
    names = np.array(v.get_feature_names_out())
    pos = np.asarray(X[df.label.values == 1].mean(axis=0)).ravel(); neg = np.asarray(X[df.label.values == 0].mean(axis=0)).ravel()
    d = pos - neg
    return {"positive_class": names[np.argsort(-d)[:k]].tolist(), "negative_class": names[np.argsort(d)[:k]].tolist()}


def ppv_at_threshold(y, p, threshold, minutes_per_alert=4):
    pred = p >= threshold
    tp = int((pred & (y == 1)).sum()); fp = int((pred & (y == 0)).sum()); fn = int((~pred & (y == 1)).sum())
    ppv = tp / (tp + fp) if tp + fp else 0.0
    return {"threshold": threshold, "tp": tp, "fp": fp, "fn": fn, "ppv": ppv, "alerts": tp + fp,
            "analyst_hours_per_tp": ((tp + fp) * minutes_per_alert / 60) / tp if tp else float("inf")}
