"""Lab 3: Building a Reproducible Pipeline (learner scaffold).

Check a step:   python run_lab.py --lab 3 --step N --script labs/lab3_pipeline.py

Scenario: Meera Iyer's platform team will run your artefact nightly on the raw export. They will not edit anything. They will page you.
Input contract for the artefact: the DataFrame returned by pd.read_csv("flows_export.csv") with nothing done to it.
Column names have leading spaces, one name is doubled, the rate columns contain Infinity, the timestamps are 12-hour.
All of that is now the pipeline's problem, not the notebook's. Select columns by name; week 2's export is column-reordered.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs"):
    sys.path.insert(0, str(p))
from common import W1  # noqa: E402

raw = pd.read_csv(W1 / "flows_export.csv", low_memory=False)
tickets = pd.read_csv(W1 / "tickets.csv")   # export_flow_id + export_ts_utc identify a ticketed flow in the export
state = {"raw": raw}

# ------------------------------------------------------------------ Step 1: build the pipeline
# Required: state["pipe"], an sklearn Pipeline containing: a FunctionTransformer that does the Lab 1 cleaning and derived
# features (log1p on counts, packet-rate ratio, bytes per packet, payload entropy, zero_duration), a ColumnTransformer with
# imputer + StandardScaler for numerics and a OneHotEncoder for categoricals, then an estimator with random_state set.
# state["pipe"] = Pipeline([...])

# ------------------------------------------------------------------ Step 2: split
# Required: state["y"] (labels aligned to raw rows), state["split"] in {"random", "time", "time_gap"},
#           state["train_idx"], state["test_idx"] (integer positions), and state["pipe"] fitted on the train rows only.
# The timestamps you need for the split are the same 12-hour strings from Lab 1. Parse them once; do not make them a feature.
# Try all three splits. Report all three numbers. Keep one and say why.

# ------------------------------------------------------------------ Step 3: leakage guards
# Required: state["checks"] with at least these keys, each a bool you computed yourself:
#   train_before_test, no_identical_rows_across_split, no_session_overlap, scaler_fit_on_train_only
# The grader recomputes each one independently. Disagreement is a failure.

# ------------------------------------------------------------------ Step 4: serialise and prove it runs
# Required: state["artefact_dir"] containing feature_pipeline.joblib and schema.json with at least
#   input_columns, sklearn, artefact_sha256, train_row_merkle
# The grader runs your artefact twice, in fresh processes, on the raw week-2 export, and compares prediction hashes.
