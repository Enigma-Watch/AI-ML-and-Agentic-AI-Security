"""Reference ingestion for the acme-soc environment.

This is the Lab 1 answer key in code form. Graders import it to build the private week-2 table.
Learners are expected to write their own version in labs/lab1_ingestion.py before reading this.
"""
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from lxml import etree

from common import FLOW_SCHEMA, sha256_line

ZEEK_RENAME = {"id.orig_h": "src_ip", "id.orig_p": "src_port", "id.resp_h": "dst_ip", "id.resp_p": "dst_port"}
NUMERIC = ["src_port", "dst_port", "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts"]


# --------------------------------------------------------------------------- loaders (Step 1)
def read_zeek_tsv(path):
    """Honour the #fields header; treat '-' as unset and '(empty)' as empty."""
    fields = None
    with open(path) as f:
        for line in f:
            if line.startswith("#fields"):
                fields = line.rstrip("\n").split("\t")[1:]
                break
    df = pd.read_csv(path, sep="\t", comment="#", header=None, names=fields, na_values=["-", "(empty)"], keep_default_na=False, low_memory=False)
    df["source_file"] = Path(path).name
    df["row_hash"] = _hash_lines(path, skip_prefix="#")
    return df


def read_zeek_json(path):
    df = pd.read_json(path, lines=True)
    df["source_file"] = Path(path).name
    df["row_hash"] = _hash_lines(path)
    return df


def _hash_lines(path, skip_prefix=None):
    out = []
    with open(path) as f:
        for line in f:
            if skip_prefix and line.startswith(skip_prefix):
                continue
            if line.strip():
                out.append(sha256_line(line.rstrip("\n")))
    return out


def read_flows_csv_raw(path):
    """Raw read. Deliberately does no cleaning; that belongs in the pipeline (Lab 3)."""
    return pd.read_csv(path, low_memory=False)


def read_windows_dir(path):
    """Parse python-evtx style XML record dumps. Never abort on a bad chunk: log it and continue."""
    recs, errors = [], []
    ns = "{http://schemas.microsoft.com/win/2004/08/events/event}"
    for fp in sorted(Path(path).glob("*.evtx.xml")):
        raw = fp.read_bytes().decode("latin-1")
        for i, chunk in enumerate(re.split(r"(?<=</Event>)\s*", raw)):
            if not chunk.strip():
                continue
            try:
                root = etree.fromstring(chunk.encode("latin-1"))
            except etree.XMLSyntaxError as e:
                errors.append({"file": fp.name, "chunk": i, "error": str(e)[:80]})
                continue
            sysm = root.find(f"{ns}System")
            d = {"host": sysm.findtext(f"{ns}Computer").split(".")[0], "event_id": int(sysm.findtext(f"{ns}EventID")),
                 "version": int(sysm.findtext(f"{ns}Version")), "system_time": sysm.find(f"{ns}TimeCreated").get("SystemTime"),
                 "record_id": int(sysm.findtext(f"{ns}EventRecordID")), "source_file": fp.name}
            for el in root.find(f"{ns}EventData"):
                d[el.get("Name")] = el.text
            recs.append(d)
    df = pd.DataFrame(recs)
    df.attrs["parse_errors"] = errors
    return df


def read_tickets(path):
    return pd.read_csv(path)


# --------------------------------------------------------------------------- schema (Step 2)
def normalise_zeek(df, sensor):
    df = df.rename(columns=ZEEK_RENAME).copy()
    for c in NUMERIC:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["service"] = df["service"].fillna("-")
    df["history"] = df["history"].fillna("")
    df["source_sensor"] = sensor
    return df


def clean_flow_columns(df):
    """Strip whitespace from names, drop the duplicated Fwd Header Length after proving equality, Infinity to NaN."""
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]
    dup = [c for c in df.columns if c == "Fwd Header Length"]
    if len(dup) == 2:
        a, b = df.iloc[:, [i for i, c in enumerate(df.columns) if c == "Fwd Header Length"]].T.values
        assert np.array_equal(a, b), "duplicate columns differ; do not drop blindly"
        df = df.loc[:, ~pd.Index(df.columns).duplicated()]
    for c in ["Flow Bytes/s", "Flow Packets/s"]:
        df[c] = pd.to_numeric(df[c].replace({"Infinity": np.nan, "inf": np.nan}), errors="coerce").replace([np.inf, -np.inf], np.nan)
    df["zero_duration"] = (df["Flow Duration"] == 0).astype(int)
    return df


# --------------------------------------------------------------------------- timestamps (Step 3)
def zeek_ts_utc(df):
    s = df["ts"]
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_datetime(s, unit="s", utc=True)
    return pd.to_datetime(s, utc=True, format="ISO8601")


def parse_12h_monotonic(series):
    """Resolve 12-hour timestamps with no AM/PM marker using file order (the exporter writes in arrival order)."""
    t = pd.to_datetime(series, format="%d/%m/%Y %I:%M:%S")
    vals = t.values.astype("datetime64[s]").astype("int64").copy()
    twelve = 12 * 3600
    add = 0
    for i in range(1, len(vals)):
        if vals[i] + add < vals[i - 1]:
            add += twelve
        vals[i] += add
    # if the whole file runs before 12:00 nothing changes; if it started in the afternoon the first block is already right
    return pd.to_datetime(vals, unit="s", utc=True)


def fix_windows_time(win, zeek_table, tolerance_min=15):
    """Detect hosts whose SystemTime is local by comparing each host's event span against the Zeek capture window.
    A host with more than 5% of events after the capture window ended is shifted back by the rounded excess."""
    win = win.copy()
    win["ts_naive"] = pd.to_datetime(win["system_time"], format="%Y-%m-%d %H:%M:%S.%f")
    z_end = zeek_table["ts_utc"].max().tz_localize(None)
    shifted = {}
    for h, g in win.groupby("host"):
        over = (g.ts_naive > z_end + pd.Timedelta(minutes=tolerance_min)).mean()
        if over > 0.05:
            shifted[h] = int(round((g.ts_naive.max() - z_end).total_seconds() / 3600))
    win["ts_utc"] = win["ts_naive"].dt.tz_localize("UTC")
    for h, dh in shifted.items():
        win.loc[win.host == h, "ts_utc"] -= pd.Timedelta(hours=dh)
    win.attrs["shifted_hosts"] = shifted
    return win


# --------------------------------------------------------------------------- dedup (Step 4)
def dedup_flows(all_flows, skew_s=1.5):
    """Remove exact replays and cross-sensor twins without collapsing legitimate repeats (beacons).
    Twin rule: same 5-tuple, same orig_bytes, timestamps within skew_s. Survivor keeps both provenance tags."""
    key = ["src_ip", "src_port", "dst_ip", "dst_port", "proto"]
    df = all_flows.sort_values(key + ["ts_utc"]).reset_index(drop=True)
    same = (df[key + ["orig_bytes"]] == df[key + ["orig_bytes"]].shift()).all(axis=1)
    close = (df["ts_utc"] - df["ts_utc"].shift()).dt.total_seconds().abs() <= skew_s
    twin = same & close
    # propagate provenance to the survivor (the first row of each twin run)
    grp = (~twin).cumsum()
    prov = df.groupby(grp)["source_sensor"].agg(lambda s: "+".join(sorted(set(s))))
    files = df.groupby(grp)["source_file"].agg(lambda s: "|".join(sorted(set(s))))
    out = df[~twin].copy()
    out["source_sensor"] = prov.values
    out["source_file"] = files.values
    return out.sort_values("ts_utc").reset_index(drop=True)


# --------------------------------------------------------------------------- end to end
def build_table(week_dir):
    week_dir = Path(week_dir)
    za = normalise_zeek(read_zeek_tsv(week_dir / "zeek_sensorA_conn.log"), "A")
    zb = normalise_zeek(read_zeek_json(week_dir / "zeek_sensorB_conn.jsonl"), "B")
    za["ts_utc"] = zeek_ts_utc(za); zb["ts_utc"] = zeek_ts_utc(zb)
    cols = FLOW_SCHEMA
    allf = pd.concat([za[cols], zb[cols]], ignore_index=True)
    table = dedup_flows(allf)
    # join the exporter's extra fields (TTL, payload prefix, rate columns) on 5-tuple + floored second
    fl = clean_flow_columns(read_flows_csv_raw(week_dir / "flows_export.csv"))
    fl["ts_floor"] = parse_12h_monotonic(fl["Timestamp"])
    fl["proto"] = fl["Protocol"].map({6: "tcp", 17: "udp"})
    fl = fl.rename(columns={"Source IP": "src_ip", "Source Port": "src_port", "Destination IP": "dst_ip", "Destination Port": "dst_port",
                            "Fwd TTL": "orig_ttl", "Payload Prefix": "payload_hex", "Flow Bytes/s": "flow_bytes_s", "Flow Packets/s": "flow_pkts_s"})
    table["ts_floor"] = table["ts_utc"].dt.floor("s")
    table = table.merge(fl[["src_ip", "src_port", "dst_ip", "dst_port", "proto", "ts_floor", "orig_ttl", "payload_hex", "flow_bytes_s", "flow_pkts_s", "zero_duration", "Flow ID"]],
                        on=["src_ip", "src_port", "dst_ip", "dst_port", "proto", "ts_floor"], how="left")
    table = table.rename(columns={"Flow ID": "flow_id_export"})
    table["payload_hex"] = table["payload_hex"].fillna("")
    win = fix_windows_time(read_windows_dir(week_dir / "windows"), table)
    tickets = read_tickets(week_dir / "tickets.csv")
    return table, win, tickets
