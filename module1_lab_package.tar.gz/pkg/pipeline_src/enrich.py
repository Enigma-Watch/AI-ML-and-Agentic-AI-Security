"""Enrichment used by the 'quick baseline' Daniel Okafor built.

Learners are told in Lab 2 Step 3 that they may read this file. Two of these functions leak by construction.
Read them the way you would read code Daniel handed you at 18:40 on his way out.
"""
import numpy as np
import pandas as pd


def _ns(series):
    """Timestamps as int64 nanoseconds regardless of the underlying datetime resolution."""
    return series.dt.tz_convert("UTC").values.astype("datetime64[ns]").astype("int64")

from common import host_for_ip, shannon_entropy_hex


def host_alert_count_24h(table, tickets, centered=True):
    """Number of ticketed flows from the same source host within a 24 hour window around each flow.

    centered=True  : window is [ts - 12h, ts + 12h]   (what the baseline shipped with)
    centered=False : window is [ts - 24h, ts)          (trailing only)
    """
    tk = table.merge(tickets[["uid", "ticket_id"]], on="uid", how="inner")[["src_ip", "ts_utc"]]
    out = np.zeros(len(table), dtype=int)
    for ip, g in tk.groupby("src_ip"):
        t = np.sort(_ns(g["ts_utc"]))
        idx = np.where(table["src_ip"].values == ip)[0]
        ts = _ns(table["ts_utc"])[idx]
        h12 = 12 * 3600 * 10**9
        if centered:
            lo = np.searchsorted(t, ts - h12); hi = np.searchsorted(t, ts + h12)
        else:
            lo = np.searchsorted(t, ts - 2 * h12); hi = np.searchsorted(t, ts, side="left")
        out[idx] = hi - lo
    return out


def cmdline_window(table, win, minutes=10, symmetric=True):
    """Concatenate 4688 command lines seen on the destination host near each flow.

    symmetric=True : [ts - m, ts + m]   (what the baseline shipped with)
    symmetric=False: [ts - m, ts]        (trailing only)
    """
    p = win[win.event_id == 4688]
    by_host = {h: (np.sort(_ns(g["ts_utc"])), g.sort_values("ts_utc")["CommandLine"].fillna("").values) for h, g in p.groupby("host")}
    hosts = table["dst_ip"].map(host_for_ip)
    ts = _ns(table["ts_utc"])
    m = minutes * 60 * 10**9
    out = np.empty(len(table), dtype=object)
    for i, h in enumerate(hosts.values):
        if h in by_host:
            t, c = by_host[h]
            lo = np.searchsorted(t, ts[i] - m); hi = np.searchsorted(t, ts[i] + (m if symmetric else 0))
            out[i] = " || ".join(c[lo:hi])
        else:
            out[i] = ""
    return out


def build_lab2_table(table, win, tickets, inventory=None, scoring_time=False):
    """The table the data scientist trained on. All columns present, including the ones that should not be.

    scoring_time=True reproduces what the columns look like when the model is actually run: the day's tickets do not
    exist yet, so ticket-derived columns are empty and host_alert_count_24h counts nothing. Labels are still attached
    so the grader can score. The 4688 logs do exist at nightly batch time, so cmdline_window is computed as shipped."""
    df = table.merge(tickets[["uid", "ticket_id", "analyst_note", "raised_by", "label"]], on="uid", how="left")
    df["label"] = df["label"].fillna(0).astype(int)
    df["ticket_id"] = df["ticket_id"].fillna("")
    df["analyst_note"] = df["analyst_note"].fillna("")
    df["raised_by"] = df["raised_by"].fillna("")
    if inventory is not None:
        inv = inventory.rename(columns={"ip_address": "dst_ip"})[["dst_ip", "department", "criticality"]]
        df = df.merge(inv, on="dst_ip", how="left")
        df["department"] = df["department"].fillna("unmanaged")     # the red-team workstation is not in the CMDB
        df["criticality"] = df["criticality"].fillna("unknown")
    df["bytes_per_pkt"] = df["orig_bytes"] / (df["orig_pkts"].replace(0, np.nan))
    df["payload_entropy"] = df["payload_hex"].map(shannon_entropy_hex)
    df["host_alert_count_24h"] = host_alert_count_24h(df, tickets.iloc[0:0] if scoring_time else tickets, centered=True)
    if scoring_time:
        df["ticket_id"] = ""; df["analyst_note"] = ""; df["raised_by"] = ""
    df["cmdline_window"] = cmdline_window(df, win, symmetric=True)
    return df
