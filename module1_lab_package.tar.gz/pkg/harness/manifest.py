"""Emit lab_manifest.json: the step graph, decision points, state contract and branch messages.

The AISec LabRunner UI needs (a) what to show at each step, (b) what the learner must leave in
`state`, (c) which probe to call, (d) the feedback text per branch. This file is the single source of truth for (a) to (d).
"""
import json
from pathlib import Path

from probes import MESSAGES

LABS = [
    {
        "id": 1, "title": "Data Ingestion Under Chaos", "mode": "self-paced pre-work", "minutes": 30,
        "scenario": "Three collectors, one ticketing export, one Slack message from Priya Nair, the SOC lead: 'Get me one clean table of flows with host logon context by end of day.' Every row you cannot trace to a source is a row an attacker could have inserted.",
        "sources": {"zeek_a": "data/w1/zeek_sensorA_conn.log", "zeek_b": "data/w1/zeek_sensorB_conn.jsonl", "flows": "data/w1/flows_export.csv",
                    "windows": "data/w1/windows/*.evtx.xml", "tickets": "data/w1/tickets.csv"},
        "steps": [
            {"n": 1, "title": "Load everything and watch it fail", "probe": "lab1_step1",
             "state": ["zeek_a", "zeek_b", "flows", "windows"],
             "decision": {"prompt": "How will you load the four sources?",
                          "options": {"A": "pd.read_csv on all four", "B": "format-specific parsers", "C": "write your own"}},
             "branches": ["l1s1_missing", "l1s1_fields_header", "l1s1_infinity_text", "l1s1_evtx_abort", "l1s1_ok"]},
            {"n": 2, "title": "Fix the schema", "probe": "lab1_step2", "state": ["flows (cleaned, with zero_duration)"],
             "decision": {"prompt": "Flow Bytes/s contains Infinity and NaN. What do you do?",
                          "options": {"A": "drop the rows", "B": "replace with 0", "C": "replace with NaN and add a zero_duration flag"}},
             "decision2": {"prompt": "'Fwd Header Length' appears twice.", "options": {"A": "keep both", "B": "prove equal, drop one"}},
             "branches": ["l1s2_no_flag", "l1s2_dropped_rows", "l1s2_zero_fill", "l1s2_dup_col", "l1s2_ok"]},
            {"n": 3, "title": "Normalise timestamps", "probe": "lab1_step3", "state": ["ts_utc on zeek_a, zeek_b, flows, windows"],
             "decision": {"prompt": "Timezone handling?", "options": {"A": "parse naive", "B": "assume all UTC", "C": "per-source offset, convert to UTC, tz-aware"}},
             "branches": ["l1s3_naive", "l1s3_misaligned", "l1s3_folded", "l1s3_win_local", "l1s3_ok"]},
            {"n": 4, "title": "Deduplicate", "probe": "lab1_step4", "state": ["table"],
             "decision": {"prompt": "Dedup key?", "options": {"A": "drop_duplicates() on all columns", "B": "on uid", "C": "on (src_ip, dst_ip, dst_port, proto) after dropping the ephemeral source port as noise", "D": "on 5-tuple + time proximity + bytes"}},
             "branches": ["l1s4_no_table", "l1s4_exact_only", "l1s4_beacon_killed", "l1s4_provenance", "l1s4_ok"]},
        ],
    },
    {
        "id": 2, "title": "Feature Engineering and Hidden Leakage", "mode": "in-class", "minutes": 35,
        "scenario": "Daniel Okafor's quick baseline hit 99.8% accuracy and his slide deck for the CISO, Anita Krishnan, is ready. Find out whether the number is real before it ships.",
        "sources": {"df": "data/w1/lab2_table.pkl", "enrichment_source": "pipeline_src/enrich.py"},
        "steps": [
            {"n": 1, "title": "Build the initial feature set, train the quick model", "probe": "lab2_step1", "state": ["spec", "df"],
             "branches": ["l2s1_missing", "l2s1_te_full", "l2s1_report"]},
            {"n": 2, "title": "Label-shuffle test (mandatory)", "probe": "lab2_step2", "state": ["spec", "df"], "branches": ["l2s2_fail", "l2s2_ok"]},
            {"n": 3, "title": "Investigate and decide per feature", "probe": "lab2_step3", "state": ["decisions"],
             "tools": ["feature_importance", "perm_importance", "label_rate", "single_feature_auc", "ablation", "top_tfidf_tokens", "read pipeline_src/enrich.py"],
             "decision": {"prompt": "For each of the 18 pool columns: keep, drop, or transform, with a reason."},
             "branches": ["l2s3_missing", "l2s3_review", "l2s3_ok"]},
            {"n": 4, "title": "Choose encodings", "probe": "lab2_step4", "state": ["spec"],
             "decision": {"prompt": "Encoding for service and dst_port?", "options": {"A": "one-hot both", "B": "ordinal", "C": "target encoding on full data", "D": "target encoding inside the pipeline", "E": "bucket dst_port + admin-port flag"}},
             "branches": ["l2s4_te_full", "l2s4_port_onehot", "l2s4_port_ordinal", "l2s4_ok"]},
            {"n": 5, "title": "The week-2 gate and the base-rate arithmetic", "probe": "lab2_step5", "state": ["spec", "threshold", "ppv_estimate"],
             "branches": ["l2s5_gate", "l2s5_ppv"]},
        ],
    },
    {
        "id": 3, "title": "Building a Reproducible Pipeline", "mode": "homework", "minutes": 25,
        "scenario": "Meera Iyer's platform team will run your pipeline nightly on the raw export. They will not edit anything. They will page you.",
        "sources": {"raw": "data/w1/flows_export.csv (pd.read_csv, untouched)", "tickets": "data/w1/tickets.csv"},
        "steps": [
            {"n": 1, "title": "Build the pipeline", "probe": "lab3_step1", "state": ["pipe"], "branches": ["l3s1_missing", "l3s1_no_scaler", "l3s1_unknown_error", "l3s1_ok"]},
            {"n": 2, "title": "Split the data", "probe": "lab3_step2", "state": ["split", "train_idx", "test_idx", "raw", "y", "pipe (fitted on train)"],
             "decision": {"prompt": "Which split?", "options": {"A": "stratified random 80/20", "B": "time-ordered 80/20", "C": "time-ordered with a 10-minute embargo"}},
             "branches": ["l3s2_missing", "l3s2_leaky_scaler", "l3s2_random", "l3s2_time", "l3s2_gap"]},
            {"n": 3, "title": "Validate leakage guards", "probe": "lab3_step3", "state": ["checks"], "branches": ["l3s3_missing", "l3s3_incomplete", "l3s3_disagree", "l3s3_ok"]},
            {"n": 4, "title": "Serialise, record the schema, run on the raw week-2 file", "probe": "lab3_step4", "state": ["artefact_dir"],
             "branches": ["l3s4_missing", "l3s4_schema", "l3s4_crash", "l3s4_nondeterministic", "l3s4_ok"]},
        ],
    },
]


def write(path):
    out = {"environment": "acme-soc", "labs": LABS, "messages": MESSAGES}
    Path(path).write_text(json.dumps(out, indent=1))
    return out
