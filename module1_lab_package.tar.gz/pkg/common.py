"""Shared constants and helpers for the Module 1 lab package."""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
W1 = DATA / "w1"
W2 = DATA / "private" / "w2"

ALPH = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

WEEKS = {
    "w1": dict(date="2026-09-01", benign=280_000, red_ip="10.40.7.99", red_ttl=64,
               red_vlan=40, quic=False, sensor_b_vlans=(30, 40)),
    "w2": dict(date="2026-09-08", benign=300_000, red_ip="10.12.3.44", red_ttl=128,
               red_vlan=12, quic=True, sensor_b_vlans=(30, 40)),
}

BEACON_SRC = "10.40.7.22"
BEACON_DST = "198.51.100.14"
SENSOR_B_OFFSET = "+02:00"
WIN_LOCAL_SHIFT_H = 2

FLOW_SCHEMA = [
    "ts_utc", "uid", "src_ip", "src_port", "dst_ip", "dst_port", "proto", "service",
    "duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "conn_state",
    "history", "source_sensor", "source_file", "row_hash",
]


def zeek_uids(rng, n):
    idx = rng.integers(0, len(ALPH), size=(n, 17))
    return ["C" + "".join(ALPH[i] for i in row) for row in idx]


def shannon_entropy_hex(h):
    if not isinstance(h, str) or len(h) < 2:
        return 0.0
    b = bytes.fromhex(h)
    if not b:
        return 0.0
    c = Counter(b)
    n = len(b)
    return -sum((v / n) * math.log2(v / n) for v in c.values())


def sha256_line(s):
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()


def load_truth(week_dir):
    with open(Path(week_dir) / "truth.json") as f:
        return json.load(f)


def host_for_ip(ip):
    """Acme naming convention: WS-0VV-nn at 10.VV.1.nn, SRV-020-nn at 10.20.0.(10+nn)."""
    p = ip.split(".")
    if len(p) != 4 or p[0] != "10":
        return None
    v, c, d = int(p[1]), int(p[2]), int(p[3])
    if v == 20 and c == 0 and 11 <= d <= 25:
        return f"SRV-020-{d - 10:02d}"
    if v in (10, 30, 40) and c == 1:
        return f"WS-{v:03d}-{d:02d}"
    return None


def pr_auc(y, p):
    from sklearn.metrics import average_precision_score
    return float(average_precision_score(y, p))
