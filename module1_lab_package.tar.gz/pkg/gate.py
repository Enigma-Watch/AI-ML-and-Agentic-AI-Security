"""Week-2 gate. Learners never read data/private; only this module does.

gate_lab2(spec)            : train the learner's feature spec on the week-1 table, score on the private week-2 table
gate_lab3(artefact_path)   : run the learner's serialised pipeline on the raw week-2 export, twice, in fresh processes
"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent / "pipeline_src"))
sys.path.insert(0, str(Path(__file__).resolve().parent / "labs"))
from common import DATA, W1, W2, pr_auc  # noqa: E402

CACHE = DATA / "_cache"
THRESHOLDS_FILE = Path(__file__).resolve().parent / "harness" / "thresholds.json"


def thresholds():
    return json.loads(THRESHOLDS_FILE.read_text()) if THRESHOLDS_FILE.exists() else {"lab2_w2_pr_auc": 0.30, "lab3_w2_pr_auc": 0.20}


def lab2_tables():
    w1 = pd.read_pickle(CACHE / "lab2_w1.pkl"); w2 = pd.read_pickle(CACHE / "lab2_w2_scoring.pkl")
    return w1, w2


def gate_lab2(spec, n_estimators=100, seed=0):
    import lab2_tools as T
    w1, w2 = lab2_tables()
    cols = T.spec_columns(spec)
    m = T.build_model(spec, n_estimators, seed).fit(w1[cols], w1["label"].values)
    p = m.predict_proba(w2[cols])[:, 1]
    y = w2["label"].values
    return {"w2_pr_auc": pr_auc(y, p), "w2_base_rate": float(y.mean()), "w2_positives": int(y.sum()), "scores": p, "labels": y}


def _score_once(artefact_path):
    """Runs in a subprocess so that two runs share no in-memory state."""
    code = f"""
import sys, json, hashlib, joblib, pandas as pd, numpy as np
sys.path[:0] = {json.dumps([str(Path(__file__).resolve().parent), str(Path(__file__).resolve().parent / 'pipeline_src'), str(Path(__file__).resolve().parent / 'labs'), str(Path(__file__).resolve().parent / 'solutions')])}
raw = pd.read_csv({json.dumps(str(W2 / 'flows_export.csv'))}, low_memory=False)
try:
    pipe = joblib.load({json.dumps(str(artefact_path))})
    p = pipe.predict_proba(raw)[:, 1]
    print(json.dumps({{"ok": True, "hash": hashlib.sha256(np.round(p, 8).tobytes()).hexdigest(), "scores": p.tolist()}}))
except Exception as e:
    print(json.dumps({{"ok": False, "error": type(e).__name__ + ": " + str(e)[:300]}}))
"""
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=1800)
    lines = [l for l in r.stdout.strip().splitlines() if l.startswith("{")]
    if not lines:
        return {"ok": False, "error": (r.stderr or r.stdout)[-400:]}
    return json.loads(lines[-1])


def gate_lab3(artefact_path):
    ref = pd.read_pickle(W2 / "_reference_flows.pkl")
    y = ref["label"].values
    r1 = _score_once(artefact_path)
    if not r1["ok"]:
        return {"ok": False, "error": r1["error"]}
    r2 = _score_once(artefact_path)
    p = np.array(r1["scores"])
    return {"ok": True, "w2_pr_auc": pr_auc(y, p), "w2_positives": int(y.sum()), "reproducible": r1["hash"] == r2.get("hash"),
            "prediction_hash": r1["hash"], "scores": p, "labels": y}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("--lab", type=int, required=True); ap.add_argument("--spec"); ap.add_argument("--artefact")
    a = ap.parse_args()
    if a.lab == 2:
        r = gate_lab2(json.load(open(a.spec))); print({k: v for k, v in r.items() if k not in ("scores", "labels")})
    else:
        r = gate_lab3(a.artefact); print({k: v for k, v in r.items() if k not in ("scores", "labels")})
