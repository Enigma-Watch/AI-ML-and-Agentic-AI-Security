"""Run a learner script for one lab and apply the probe for a step.

  python run_lab.py --lab 1 --step 3 --script labs/lab1_ingestion.py
  python run_lab.py --lab 2 --step 5 --solution          # runs the reference solution instead
  python run_lab.py --lab 3 --all --solution             # every step in order, stops at the first STOP

The learner script must define a dict named `state` (see README for the per-lab state contract).
The script is executed once; probes for the requested steps are then applied to `state` in order.
"""
import argparse
import runpy
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs", ROOT / "solutions", ROOT / "fable"):
    sys.path.insert(0, str(p))

from probes import PROBES  # noqa: E402

SOLUTIONS = {1: ROOT / "solutions" / "lab1_solution.py", 2: ROOT / "solutions" / "lab2_solution.py", 3: ROOT / "solutions" / "lab3_solution_run.py"}
LAST_STEP = {1: 4, 2: 5, 3: 4}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lab", type=int, required=True)
    ap.add_argument("--step", type=int)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--script")
    ap.add_argument("--solution", action="store_true")
    a = ap.parse_args()
    script = SOLUTIONS[a.lab] if a.solution else a.script
    if not script:
        ap.error("give --script or --solution")
    t0 = time.time()
    ns = runpy.run_path(str(script), run_name="__lab__")
    state = ns.get("state")
    if not isinstance(state, dict):
        print("STOP: the script must define a dict named `state`."); sys.exit(2)
    print(f"script ran in {time.time() - t0:.1f}s; state keys: {sorted(state)}")
    steps = range(1, LAST_STEP[a.lab] + 1) if a.all else [a.step]
    for s in steps:
        t = time.time()
        r = PROBES[(a.lab, s)](state)
        print(f"\nLab {a.lab} Step {s} ({time.time() - t:.1f}s)\n{r}")
        if not r.ok and a.all:
            print("\nStopping at the first failed step."); sys.exit(1)


if __name__ == "__main__":
    main()
