"""Generate the acme-soc synthetic environment (week 1 public, week 2 private).

Usage: python generate_data.py [--scale 1.0] [--seed 20260901]
"""
import argparse
import json
import os
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from common import (BEACON_DST, BEACON_SRC, DATA, SENSOR_B_OFFSET, W1, W2, WEEKS,
                    WIN_LOCAL_SHIFT_H, zeek_uids)

# ----------------------------------------------------------------------------- hosts
PEOPLE = [
    ("Farah Siddiqui", "fsiddiqui", "Finance"), ("Joseph Mwangi", "jmwangi", "Finance"),
    ("Beatriz Alves", "balves", "Finance"), ("Tomas Lindqvist", "tlindqvist", "Finance"),
    ("Aisha Bello", "abello", "Engineering"), ("Wei Chen", "wchen", "Engineering"),
    ("Rafael Duarte", "rduarte", "Engineering"), ("Hannah Vogel", "hvogel", "Engineering"),
    ("Nikhil Sharma", "nsharma", "Engineering"), ("Ingrid Halvorsen", "ihalvorsen", "Engineering"),
    ("Omar Haddad", "ohaddad", "Engineering"), ("Grace Mutiso", "gmutiso", "Engineering"),
    ("Yuki Tanaka", "ytanaka", "Plant Operations"), ("Sofia Marchetti", "smarchetti", "Plant Operations"),
    ("Ben Kowalski", "bkowalski", "Plant Operations"), ("Laila Nasser", "lnasser", "Plant Operations"),
    ("Peter Odhiambo", "podhiambo", "Plant Operations"), ("Anna Novak", "anovak", "Plant Operations"),
    ("Ravi Menon", "rmenon", "Plant Operations"), ("Clara Fuentes", "cfuentes", "Plant Operations"),
    ("Jonas Berg", "jberg", "Sales"), ("Divya Krishnan", "dkrishnan", "Sales"),
    ("Michael Adeyemi", "madeyemi", "Sales"), ("Elena Petrova", "epetrova", "Sales"),
    ("Sam Whitfield", "swhitfield", "IT Operations"),
]
# Security operations centre, Acme Industrial. Named because a ticket with no author is a ticket nobody owns.
SOC = [("Priya Nair", "pnair", "SOC lead"), ("Callum Reid", "creid", "Tier 2 analyst"),
       ("Ifeoma Eze", "ieze", "Tier 2 analyst"), ("Marcus Lindberg", "mlindberg", "Tier 1 analyst"),
       ("Sunita Rao", "srao", "Detection engineer")]
# Named non-SOC staff who appear in the scenario text: Anita Krishnan (CISO), Daniel Okafor (data science),
# Meera Iyer (platform engineering lead), Sam Whitfield (IT operations, owns the server estate and svc_backup).
SERVICE_ACCOUNTS = {"w1": ("svc_backup", "Veeam backup service, owned by Sam Whitfield"),
                    "w2": ("svc_deploy", "Octopus deploy service, owned by Wei Chen")}

WIN_HOSTS = ([f"WS-040-{i:02d}" for i in range(1, 13)] + [f"WS-030-{i:02d}" for i in range(1, 9)]
             + [f"WS-010-{i:02d}" for i in range(1, 6)] + [f"SRV-020-{i:02d}" for i in range(1, 16)])


def host_ip(h):
    kind, v, n = h.split("-")
    v, n = int(v), int(n)
    return f"10.20.0.{10 + n}" if kind == "SRV" else f"10.{v}.1.{n}"


IP2HOST = {host_ip(h): h for h in WIN_HOSTS}
SERVERS = [host_ip(h) for h in WIN_HOSTS if h.startswith("SRV")] + [f"10.20.0.{d}" for d in range(26, 41)]
DNS = "10.20.0.11"
EXTERNAL = [f"203.0.113.{d}" for d in range(2, 60)] + [f"93.184.216.{d}" for d in range(2, 60)] + \
           [f"198.51.100.{d}" for d in range(20, 60)]

SERVICES = {  # name: (proto, port, weight, mean_orig_bytes, mean_resp_bytes, internal)
    "dns": ("udp", 53, 0.30, 70, 180, True),
    "ssl": ("tcp", 443, 0.28, 2400, 40000, False),
    "http": ("tcp", 80, 0.10, 900, 12000, False),
    "smb": ("tcp", 445, 0.10, 6000, 30000, True),
    "kerberos": ("tcp", 88, 0.08, 1500, 1800, True),
    "ldap": ("tcp", 389, 0.07, 800, 4000, True),
    "ntp": ("udp", 123, 0.04, 48, 48, True),
    "ssh": ("tcp", 22, 0.015, 4000, 9000, True),
    "rdp": ("tcp", 3389, 0.01, 90000, 900000, True),
    "winrm": ("tcp", 5985, 0.005, 3000, 5000, True),
}
BENIGN_HISTORY = {"SF": ["ShADadFf", "ShAdDaFf", "ShADadfF", "Dd", "DdAaFf"], "S0": ["S"], "REJ": ["Sr"],
                  "RSTO": ["ShADadR"], "OTH": ["DdA"]}
BENIGN_CMDS = ["C:\\Windows\\System32\\svchost.exe -k netsvcs", "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe --type=renderer",
               "C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE", "powershell.exe -File C:\\scripts\\backup.ps1",
               "C:\\ProgramData\\Microsoft\\Windows Defender\\Platform\\MsMpEng.exe", "C:\\Windows\\System32\\conhost.exe 0xffffffff",
               "C:\\Windows\\System32\\wbem\\WmiPrvSE.exe", "C:\\Program Files\\Microsoft VS Code\\Code.exe", "taskhostw.exe",
               "C:\\Windows\\System32\\SearchIndexer.exe /Embedding", "gpupdate.exe /target:computer"]
ATTACKER_CMDS = ["C:\\Windows\\Temp\\svc.exe -k dump", "cmd.exe /c whoami /all", "rundll32.exe C:\\Windows\\Temp\\m.dll,Start",
                 "cmd.exe /c net view \\\\10.20.0.12"]
IR_CMDS_W2 = ["C:\\Program Files\\CrowdStrike\\CSFalconService.exe --network-contain", "powershell.exe Remove-ADGroupMember -Identity Admins -Members svc_deploy",
              "C:\\Program Files\\Velociraptor\\velociraptor.exe collect --artifact Windows.Triage", "wevtutil.exe epl Security C:\\ir\\sec.evtx",
              "powershell.exe Set-ADAccountPassword -Identity svc_deploy -Reset"]
IR_CMDS = ["powershell.exe Stop-Service -Name RemoteRegistry -Force", "net user svc_backup /active:no",
           "C:\\Program Files\\EDR\\quarantine.exe --host-isolate", "powershell.exe Disable-LocalUser -Name svc_backup",
           "C:\\Program Files\\EDR\\collector.exe --triage --case INC"]


# ----------------------------------------------------------------------------- flows
def gen_benign(cfg, rng, t0, n):
    names = list(SERVICES)
    w = np.array([SERVICES[s][2] for s in names])
    if cfg["quic"]:
        names.append("quic")
        w = np.append(w, 0.06)
    w = w / w.sum()
    svc = rng.choice(names, size=n, p=w)
    vl = rng.choice([10, 12, 30, 40], size=n, p=[0.3, 0.25, 0.2, 0.25])
    src = [f"10.{v}.{rng.integers(1, 9)}.{rng.integers(1, 41)}" for v in vl]
    srv_src = rng.random(n) < 0.08  # server-to-server traffic
    src = np.where(srv_src, rng.choice(SERVERS, size=n), src)
    dst, port, proto, ob, rb, internal = [], [], [], [], [], []
    for s in svc:
        if s == "quic":
            dst.append(rng.choice(EXTERNAL)); port.append(443); proto.append("udp"); ob.append(3000); rb.append(60000)
        else:
            p, pt, _, mo, mr, intl = SERVICES[s]
            proto.append(p); port.append(pt); ob.append(mo); rb.append(mr)
            dst.append(DNS if s == "dns" else (rng.choice(SERVERS) if intl else rng.choice(EXTERNAL)))
    ob = np.array(ob) * rng.lognormal(0, 0.9, n)
    rb = np.array(rb) * rng.lognormal(0, 0.9, n)
    state = rng.choice(["SF", "S0", "REJ", "RSTO", "OTH"], size=n, p=[0.86, 0.045, 0.03, 0.04, 0.025])
    dur = rng.exponential(2.5, n)
    dur[np.isin(svc, ["dns", "ntp"])] = rng.exponential(0.05, n)[np.isin(svc, ["dns", "ntp"])]
    zero = np.isin(state, ["S0", "REJ"]) | ((rng.random(n) < 0.012) & (np.array(proto) == "udp"))
    dur[zero] = 0.0
    opk = np.maximum(1, (ob / 600 + rng.random(n) * 4).astype(int))
    rpk = np.maximum(0, (rb / 900 + rng.random(n) * 4).astype(int))
    opk[zero] = 1; rpk[zero] = np.where(np.isin(state[zero], ["S0"]), 0, 1)
    ob[zero] = 0; rb[zero] = 0
    hist = [rng.choice(BENIGN_HISTORY[s]) for s in state]
    svc = np.where(np.isin(state, ["S0", "REJ"]), "-", svc)
    ttl = np.where(srv_src, rng.choice([128, 64], size=n, p=[0.6, 0.4]), 128)
    ts = t0 + pd.to_timedelta(rng.random(n) * 6 * 3600, unit="s")
    return pd.DataFrame(dict(ts=ts, src_ip=src, src_port=rng.integers(49152, 65535, n), dst_ip=dst, dst_port=port,
                             proto=proto, service=svc, duration=dur, orig_bytes=ob.astype(int), resp_bytes=rb.astype(int),
                             orig_pkts=opk, resp_pkts=rpk, conn_state=state, history=hist, orig_ttl=ttl,
                             label=0, session_id="", attack_type=""))


def gen_beacon(rng, t0):
    ts = t0 + pd.to_timedelta(np.arange(360) * 60 + rng.random(360) * 0.4, unit="s")
    return pd.DataFrame(dict(ts=ts, src_ip=BEACON_SRC, src_port=rng.integers(49152, 65535, 360), dst_ip=BEACON_DST,
                             dst_port=443, proto="tcp", service="ssl", duration=rng.normal(0.21, 0.02, 360),
                             orig_bytes=rng.integers(415, 426, 360), resp_bytes=rng.integers(305, 316, 360),
                             orig_pkts=6, resp_pkts=5, conn_state="SF", history="ShADadFf", orig_ttl=128,
                             label=0, session_id="beacon", attack_type=""))


def gen_attack(cfg, rng, t0, week):
    red = cfg["red_ip"]; ttl = cfg["red_ttl"]
    rows = []
    if week == "w1":
        plan = [("scan", 72, 6, 600, None), ("lateral_smb", 125, 15, 250, 445), ("lateral_rdp", 160, 12, 150, 3389),
                ("exfil", 190, 6, 20, 443), ("lateral_smb", 220, 12, 200, 445), ("scan", 260, 4, 200, None),
                ("lateral_rdp", 300, 12, 150, 3389), ("exfil", 325, 6, 20, 443), ("lateral_smb", 340, 14, 150, 445)]
    else:
        plan = [("scan", 95, 4, 40, None), ("lateral_winrm", 150, 10, 40, 5985), ("lateral_ssh", 210, 8, 25, 22),
                ("scan", 280, 3, 20, None), ("lateral_winrm", 320, 10, 25, 5985)]
    for i, (kind, start_min, dur_min, n, port) in enumerate(plan):
        sid = f"{week}-S{i + 1}"
        ts = t0 + pd.to_timedelta(start_min * 60 + np.sort(rng.random(n)) * dur_min * 60, unit="s")
        if kind == "scan":
            dst = [f"10.20.0.{rng.integers(10, 41)}" if rng.random() < 0.7 else f"10.{rng.choice([10, 30, 40])}.1.{rng.integers(1, 41)}" for _ in range(n)]
            ports = rng.choice([22, 80, 135, 139, 443, 445, 3389, 5985, 8080, 1433], size=n)
            rows.append(pd.DataFrame(dict(ts=ts, src_ip=red, src_port=rng.integers(49152, 65535, n), dst_ip=dst, dst_port=ports,
                                          proto="tcp", service="-", duration=0.0, orig_bytes=0, resp_bytes=0, orig_pkts=1,
                                          resp_pkts=np.where(rng.random(n) < 0.6, 0, 1), conn_state=np.where(rng.random(n) < 0.6, "S0", "REJ"),
                                          history=["S"] * n, orig_ttl=ttl, label=1, session_id=sid, attack_type="scan")))
        elif kind == "exfil":
            rows.append(pd.DataFrame(dict(ts=ts, src_ip=red, src_port=rng.integers(49152, 65535, n), dst_ip="203.0.113.50", dst_port=443,
                                          proto="tcp", service="ssl", duration=rng.uniform(20, 120, n), orig_bytes=rng.integers(4_000_000, 30_000_000, n),
                                          resp_bytes=rng.integers(2000, 9000, n), orig_pkts=rng.integers(3000, 22000, n), resp_pkts=rng.integers(900, 4000, n),
                                          conn_state="SF", history="ShADadFf", orig_ttl=ttl, label=1, session_id=sid, attack_type="exfil")))
        else:
            svc = {445: "smb", 3389: "rdp", 5985: "winrm", 22: "ssh"}[port]
            dst = rng.choice(SERVERS[:15], size=n)
            ob = rng.lognormal(np.log(SERVICES[svc][3] * 1.8), 0.8, n); rb = rng.lognormal(np.log(SERVICES[svc][4] * 1.2), 0.8, n)
            cs = np.where(rng.random(n) < 0.15, "RSTO", "SF")
            rows.append(pd.DataFrame(dict(ts=ts, src_ip=red, src_port=rng.integers(49152, 65535, n), dst_ip=dst, dst_port=port, proto="tcp",
                                          service=svc, duration=rng.exponential(6, n), orig_bytes=ob.astype(int), resp_bytes=rb.astype(int),
                                          orig_pkts=np.maximum(2, (ob / 600).astype(int)), resp_pkts=np.maximum(1, (rb / 900).astype(int)),
                                          conn_state=cs, history=np.where(cs == "RSTO", "ShADadR", rng.choice(BENIGN_HISTORY["SF"][:3], size=n)), orig_ttl=ttl, label=1,
                                          session_id=sid, attack_type=kind)))
    return pd.concat(rows, ignore_index=True)


def gen_flows(week, rng, scale):
    cfg = WEEKS[week]
    t0 = pd.Timestamp(cfg["date"], tz="UTC") + pd.Timedelta(hours=8)
    n = int(cfg["benign"] * scale)
    att = gen_attack(cfg, rng, t0, week)
    if scale < 1:
        att = att.sample(frac=max(scale, 0.35), random_state=1)  # keep attacks visible at small scale
    df = pd.concat([gen_benign(cfg, rng, t0, n), gen_beacon(rng, t0), att], ignore_index=True)
    df = df.sort_values("ts").reset_index(drop=True)
    df["flow_id"] = [f"{week}-{i:07d}" for i in range(len(df))]
    df["uid_a"] = zeek_uids(rng, len(df))
    df["payload_hex"] = payloads(df, rng)
    return df, t0


def payloads(df, rng):
    n = len(df)
    out = np.empty(n, dtype=object)
    enc = df["service"].isin(["ssl", "quic", "ssh"]).values | (df["attack_type"] == "exfil").values
    z = (df["orig_bytes"] == 0).values
    for i in range(n):
        if z[i]:
            out[i] = ""
        elif enc[i]:
            out[i] = rng.bytes(32).hex()
        else:
            k = rng.integers(0, 4)
            base = [b"GET /index.html HTTP/1.1\r\nHost: ", b"\xffSMB\x72\x00\x00\x00\x00\x18\x53\xc8", b"\x00\x01\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03www", b"0\x82\x01"][k]
            out[i] = (base + rng.bytes(max(0, 32 - len(base)))).hex()
    return out


# ----------------------------------------------------------------------------- writers
ZEEK_FIELDS = ["ts", "uid", "id.orig_h", "id.orig_p", "id.resp_h", "id.resp_p", "proto", "service", "duration", "orig_bytes",
               "resp_bytes", "conn_state", "local_orig", "local_resp", "missed_bytes", "history", "orig_pkts", "orig_ip_bytes",
               "resp_pkts", "resp_ip_bytes", "tunnel_parents"]
ZEEK_TYPES = ["time", "string", "addr", "port", "addr", "port", "enum", "string", "interval", "count", "count", "string", "bool",
              "bool", "count", "string", "count", "count", "count", "count", "set[string]"]


def zeek_rows(df, uid_col, ts_epoch=True):
    ts = df["ts"].astype("int64") / 1e9
    svc = df["service"].replace({"-": "-"})
    rows = pd.DataFrame({
        "ts": [f"{t:.6f}" for t in ts] if ts_epoch else df["ts"],
        "uid": df[uid_col], "id.orig_h": df.src_ip, "id.orig_p": df.src_port, "id.resp_h": df.dst_ip, "id.resp_p": df.dst_port,
        "proto": df.proto, "service": svc, "duration": np.where(df.duration > 0, df.duration.round(6).astype(str), "-"),
        "orig_bytes": df.orig_bytes, "resp_bytes": df.resp_bytes, "conn_state": df.conn_state,
        "local_orig": "T", "local_resp": np.where(df.dst_ip.str.startswith("10."), "T", "F"), "missed_bytes": 0,
        "history": df.history, "orig_pkts": df.orig_pkts, "orig_ip_bytes": df.orig_bytes + 40 * df.orig_pkts,
        "resp_pkts": df.resp_pkts, "resp_ip_bytes": df.resp_bytes + 40 * df.resp_pkts, "tunnel_parents": "(empty)"})
    return rows


def write_zeek_a(df, out, replay_start, replay_min):
    rows = zeek_rows(df, "uid_a")
    lines = rows.astype(str).agg("\t".join, axis=1).tolist()
    m = (df.ts >= replay_start) & (df.ts < replay_start + pd.Timedelta(minutes=replay_min))
    replay = [lines[i] for i in np.where(m.values)[0]]  # log-rotation replay: exact duplicate lines appended
    hdr = ["#separator \\x09", "#set_separator\t,", "#empty_field\t(empty)", "#unset_field\t-", "#path\tconn",
           f"#open\t{df.ts.min().strftime('%Y-%m-%d-%H-%M-%S')}", "#fields\t" + "\t".join(ZEEK_FIELDS), "#types\t" + "\t".join(ZEEK_TYPES)]
    with open(out, "w") as f:
        f.write("\n".join(hdr + lines + replay) + "\n#close\t" + df.ts.max().strftime("%Y-%m-%d-%H-%M-%S") + "\n")
    return int(m.sum())


def write_zeek_b(df, out, rng, vlans):
    v_src = df.src_ip.str.split(".").str[1].astype(int); v_dst = df.dst_ip.str.split(".").str[1].astype(int)
    m = (v_src.isin(vlans) | v_dst.isin(vlans)) & df.src_ip.str.startswith("10.")
    sub = df[m].copy()
    sub["ts"] = sub.ts + pd.to_timedelta(rng.uniform(0.3, 0.8, len(sub)), unit="s")
    sub["uid_b"] = zeek_uids(rng, len(sub))
    rows = zeek_rows(sub, "uid_b", ts_epoch=False)
    rows["ts"] = [t.tz_convert(SENSOR_B_OFFSET).isoformat(timespec="microseconds") for t in sub.ts]
    rows["duration"] = np.where(sub.duration > 0, sub.duration.round(6), np.nan)
    with open(out, "w") as f:
        for r in rows.to_dict("records"):
            r = {k: v for k, v in r.items() if not (v == "-" or (isinstance(v, float) and np.isnan(v)) or v == "(empty)")}
            f.write(json.dumps(r) + "\n")
    return int(m.sum()), sub[["flow_id", "uid_b"]]


FLOW_COLS = ["Flow ID", " Source IP", " Source Port", " Destination IP", " Destination Port", " Protocol", " Timestamp",
             " Flow Duration", " Total Fwd Packets", " Total Backward Packets", "Total Length of Fwd Packets",
             " Total Length of Bwd Packets", " Fwd Header Length", "Flow Bytes/s", " Flow Packets/s", " Fwd Header Length",
             " Fwd TTL", " Service", " Conn State", " History", " Payload Prefix"]


def write_flows_csv(df, out, rng, reorder):
    pnum = df.proto.map({"tcp": 6, "udp": 17})
    dur_us = (df.duration * 1e6).round().astype(int)
    tot = df.orig_bytes + df.resp_bytes; pk = df.orig_pkts + df.resp_pkts
    with np.errstate(divide="ignore", invalid="ignore"):
        bps = np.where(dur_us > 0, tot / df.duration, np.where(tot > 0, np.inf, np.nan))
        pps = np.where(dur_us > 0, pk / df.duration, np.where(pk > 0, np.inf, np.nan))
    ts12 = [f"{t.day}/{t.month}/{t.year} {t.hour % 12 or 12}:{t.minute:02d}:{t.second:02d}" for t in df.ts]  # no AM/PM marker
    cols = [df.src_ip + "-" + df.dst_ip + "-" + df.src_port.astype(str) + "-" + df.dst_port.astype(str) + "-" + pnum.astype(str),
            df.src_ip, df.src_port, df.dst_ip, df.dst_port, pnum, ts12, dur_us, df.orig_pkts, df.resp_pkts, df.orig_bytes,
            df.resp_bytes, df.orig_pkts * 20, bps, pps, df.orig_pkts * 20, df.orig_ttl, df.service, df.conn_state, df.history, df.payload_hex]
    frame = pd.concat([pd.Series(c, name=str(i)).reset_index(drop=True) for i, c in enumerate(cols)], axis=1)
    frame.columns = range(len(FLOW_COLS))
    names = list(FLOW_COLS)
    order = list(range(len(names)))
    if reorder:
        order = list(rng.permutation(len(names)))
    frame = frame[order]
    hdr = ",".join(names[i] for i in order)
    body = frame.to_csv(index=False, header=False, float_format="%.6f")
    body = body.replace("inf,", "Infinity,").replace("inf\n", "Infinity\n")
    with open(out, "w") as f:
        f.write(hdr + "\n" + body)
    # keep a hidden flow_id map for the grader
    return pd.DataFrame({"flow_id": df.flow_id, "Flow ID": cols[0].values, "ts_floor": df.ts.dt.floor("s")})


def write_windows(df, out_dir, rng, cfg, t0, local_hosts, corrupt_host, week):
    out_dir.mkdir(parents=True, exist_ok=True)
    recs = {h: [] for h in WIN_HOSTS}
    users = [u for _, u, _ in PEOPLE[:8]] + ["svc_backup", "svc_deploy", "administrator"] + [u for _, u, _ in SOC[:2]]

    def add(host, ts, eid, data, version=2):
        recs[host].append((ts, eid, data, version))

    # benign process creation and logons
    for h in WIN_HOSTS:
        for _ in range(int(280 * (len(df) / 280_000) ** 0.5) + 60):
            add(h, t0 + pd.Timedelta(seconds=float(rng.random() * 21600)), 4688,
                {"SubjectUserName": rng.choice(users[:8]), "NewProcessName": "C:\\Windows\\System32\\x.exe",
                 "CommandLine": rng.choice(BENIGN_CMDS)})
        for _ in range(40):
            add(h, t0 + pd.Timedelta(seconds=float(rng.random() * 21600)), 4625,
                {"TargetUserName": rng.choice(users), "LogonType": "3", "IpAddress": f"10.{rng.choice([10, 12, 30, 40])}.1.{rng.integers(1, 41)}", "Status": "0xC000006D"})
    logon_flows = df[df.service.isin(["smb", "ldap", "kerberos", "rdp", "winrm", "ssh"]) & df.dst_ip.isin(IP2HOST)]
    logon_flows = logon_flows.sample(frac=0.25, random_state=3)
    for r in logon_flows.itertuples():
        add(IP2HOST[r.dst_ip], r.ts + pd.Timedelta(seconds=float(rng.uniform(0.2, 2))), 4624,
            {"SubjectUserSid": "S-1-5-18", "TargetUserName": ("svc_backup" if week == "w1" else "svc_deploy") if r.label else rng.choice(users[:8]),
             "LogonType": "10" if r.service == "rdp" else "3", "IpAddress": r.src_ip, "AuthenticationPackageName": "Kerberos"},
            version=1 if rng.random() < 0.12 else 2)
    # attacker commands and IR containment on compromised hosts
    att = df[(df.label == 1) & df.dst_ip.isin(IP2HOST)]
    for (sid, dst), g in att.groupby(["session_id", "dst_ip"]):
        h = IP2HOST[dst]; first = g.ts.min()
        for c in rng.choice(ATTACKER_CMDS, size=2, replace=False):
            add(h, first + pd.Timedelta(seconds=float(rng.uniform(20, 90))), 4688, {"SubjectUserName": SERVICE_ACCOUNTS[week][0], "NewProcessName": c.split(" ")[0], "CommandLine": c})
        if rng.random() < 0.75:
            for c in rng.choice(IR_CMDS if week == "w1" else IR_CMDS_W2, size=3, replace=False):
                add(h, first + pd.Timedelta(seconds=float(rng.uniform(120, 480))), 4688, {"SubjectUserName": rng.choice([u for _, u, _ in SOC[1:4]]), "NewProcessName": c.split(" ")[0], "CommandLine": c})
    counts = {}
    for h, lst in recs.items():
        lst.sort(key=lambda r: r[0])
        parts = []
        for i, (ts, eid, data, ver) in enumerate(lst):
            st = ts + pd.Timedelta(hours=WIN_LOCAL_SHIFT_H) if h in local_hosts else ts
            d = dict(data)
            if eid == 4624 and ver == 1:
                d.pop("LogonType", None)  # older template omits LogonType and ElevatedToken
            elif eid == 4624:
                d["ElevatedToken"] = "%%1843"
            dx = "".join(f'<Data Name="{k}">{v}</Data>' for k, v in d.items())
            parts.append(f'<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><System><Provider Name="Microsoft-Windows-Security-Auditing" Guid="{{54849625-5478-4994-a5ba-3e3b0328c30d}}"></Provider>'
                         f'<EventID Qualifiers="">{eid}</EventID><Version>{ver}</Version><Level>0</Level><Task>12544</Task><Opcode>0</Opcode><Keywords>0x8020000000000000</Keywords>'
                         f'<TimeCreated SystemTime="{st.strftime("%Y-%m-%d %H:%M:%S.%f")}"></TimeCreated><EventRecordID>{100000 + i}</EventRecordID>'
                         f'<Correlation ActivityID="" RelatedActivityID=""></Correlation><Execution ProcessID="712" ThreadID="4380"></Execution><Channel>Security</Channel>'
                         f'<Computer>{h}.acme.local</Computer><Security UserID=""></Security></System><EventData>{dx}</EventData></Event>')
        blob = "\n".join(parts)
        if h == corrupt_host:
            cut = int(len(blob) * 0.4)
            cut = blob.find("</Event>", cut) + 8
            blob = blob[:cut] + "\n" + rng.bytes(512).decode("latin-1") + "\n" + blob[cut:]
        with open(out_dir / f"{h}.evtx.xml", "w", encoding="latin-1", errors="replace") as f:
            f.write(blob + "\n")
        counts[h] = len(lst)
    return counts


OS_BUILDS = {"WS": ["10.0.19045.4046 (Win10 22H2)", "10.0.22631.3155 (Win11 23H2)"], "SRV": ["10.0.20348.2322 (Server 2022)", "10.0.17763.5576 (Server 2019)"]}


def write_inventory(out, rng):
    """CMDB export. Real SOCs join telemetry to an inventory like this one; the IP-to-host convention is not magic."""
    rows = []
    for i, h in enumerate(WIN_HOSTS):
        kind = h.split("-")[0]
        if kind == "SRV":
            owner_name, owner_user, department = "Sam Whitfield", "swhitfield", "IT Operations"
        else:
            owner_name, owner_user, department = PEOPLE[i % len(PEOPLE)]
        rows.append({"hostname": h, "ip_address": host_ip(h), "owner_name": owner_name, "owner_username": owner_user,
                     "department": department, "vlan": int(h.split("-")[1]), "os_build": rng.choice(OS_BUILDS[kind]),
                     "criticality": "high" if kind == "SRV" else rng.choice(["low", "medium"]),
                     "last_seen_cmdb": "2026-08-31"})
    pd.DataFrame(rows).to_csv(out, index=False)
    return rows


def write_tickets(df, out, uid_b_map, week, fmap):
    """Ticketing export from Acme's ITSM. Positives only, because tickets are written about incidents, not about Tuesdays."""
    att = df[df.label == 1].merge(uid_b_map, on="flow_id", how="left").merge(fmap, on="flow_id", how="left")
    svc = SERVICE_ACCOUNTS[week][0]
    eng = "Whitaker" if week == "w1" else "Halloran"
    notes = {"scan": "Confirmed red-team port sweep from {ip} ({eng} engagement). Source host isolated by EDR. Raised by {a}, reviewed with Priya Nair.",
             "lateral_smb": "Red-team lateral movement over SMB from {ip} using " + svc + ". Account disabled and host quarantined by {a}.",
             "lateral_rdp": "Red-team RDP lateral movement from {ip}. Sessions terminated, host quarantined. {a} notified the asset owner.",
             "exfil": "Staged data exfiltration to 203.0.113.50 from {ip}. Egress blocked at the proxy on {a}'s request.",
             "lateral_winrm": "WinRM lateral movement from {ip} (" + eng + " engagement). " + svc + " disabled by {a}.",
             "lateral_ssh": "SSH lateral movement from {ip} (" + eng + " engagement). Keys rotated by {a}."}
    order = sorted(att.session_id.unique())
    sids = {s: f"INC-2026-{4100 + i}" for i, s in enumerate(order)}
    raised = {s: SOC[1 + i % 3][0] for i, s in enumerate(order)}          # Callum Reid, Ifeoma Eze, Marcus Lindberg
    t = pd.DataFrame({"ticket_id": att.session_id.map(sids), "uid": att.uid_a, "export_flow_id": att["Flow ID"],
                      "export_ts_utc": att["ts_floor"].dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
                      "analyst_note": [notes[a].format(ip=ip, a=raised[sid], eng=eng) for a, ip, sid in zip(att.attack_type, att.src_ip, att.session_id)],
                      "raised_by": att.session_id.map(raised), "closed_by": SOC[0][0], "label": 1})
    t.to_csv(out, index=False)
    return t


def build_week(week, rng, scale):
    cfg = WEEKS[week]
    out = W1 if week == "w1" else W2
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    (out / "windows").mkdir()
    df, t0 = gen_flows(week, rng, scale)
    replay_start = t0 + pd.Timedelta(minutes=120)
    n_replay = write_zeek_a(df, out / "zeek_sensorA_conn.log", replay_start, 15)
    n_b, uid_b_map = write_zeek_b(df, out / "zeek_sensorB_conn.jsonl", rng, cfg["sensor_b_vlans"])
    fmap = write_flows_csv(df, out / "flows_export.csv", rng, reorder=(week == "w2"))
    local_hosts = ["WS-030-02", "WS-030-05", "SRV-020-09"]
    corrupt = "WS-040-05"
    wcounts = write_windows(df, out / "windows", rng, cfg, t0, local_hosts, corrupt, week)
    inv = write_inventory(out / "asset_inventory.csv", rng)
    tickets = write_tickets(df, out / "tickets.csv", uid_b_map, week, fmap)
    truth = dict(week=week, date=cfg["date"], red_ip=cfg["red_ip"], red_ttl=cfg["red_ttl"], n_flows_unique=int(len(df)),
                 n_replay_dupes=n_replay, n_sensor_b=n_b, n_beacon=360, beacon=[BEACON_SRC, BEACON_DST], n_attack=int(df.label.sum()),
                 local_time_hosts=local_hosts, corrupt_host=corrupt, sensor_b_offset=SENSOR_B_OFFSET,
                 window_utc=[t0.isoformat(), (t0 + pd.Timedelta(hours=6)).isoformat()], windows_counts=wcounts,
                 sessions=sorted(df.session_id[df.label == 1].unique().tolist()), n_assets=len(inv))
    with open(out / "truth.json", "w") as f:
        json.dump(truth, f, indent=1)
    # hidden reference tables for the grader only (never distributed to learners)
    df.to_pickle(out / "_reference_flows.pkl")
    fmap.to_pickle(out / "_flowid_map.pkl")
    return truth


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=20260901)
    a = ap.parse_args()
    for wk in ("w1", "w2"):
        t = build_week(wk, np.random.default_rng(a.seed + (0 if wk == "w1" else 7)), a.scale)
        print(wk, {k: v for k, v in t.items() if k in ("n_flows_unique", "n_replay_dupes", "n_sensor_b", "n_attack")})
    # week-1 truth is for probes; learners must not read it, so it lives next to the data but the README says so.
    print("done", DATA)
