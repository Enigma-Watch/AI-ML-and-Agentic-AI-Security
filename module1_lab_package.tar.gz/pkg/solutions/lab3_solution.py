"""Lab 3 reference solution. Input contract: the raw flows_export.csv as read by pd.read_csv, untouched."""
import hashlib
import json
import platform
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "pipeline_src"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "labs"))
from common import shannon_entropy_hex  # noqa: E402
from ingest import clean_flow_columns, parse_12h_monotonic  # noqa: E402
from lab2_tools import bucket_port  # noqa: E402

NUM = ["duration_s", "log_orig_bytes", "log_resp_bytes", "log_orig_pkts", "log_resp_pkts", "pkt_rate_ratio", "bytes_per_pkt",
       "payload_entropy", "zero_duration"]
CAT = ["proto", "Service", "Conn State", "History"]


def clean_raw(df):
    """Everything Lab 1 taught, inside the artefact: names, duplicate column, Infinity, derived features. Select by NAME."""
    df = clean_flow_columns(df)
    df["proto"] = df["Protocol"].map({6: "tcp", 17: "udp"}).fillna("other")
    df["duration_s"] = df["Flow Duration"] / 1e6
    for a, b in [("log_orig_bytes", "Total Length of Fwd Packets"), ("log_resp_bytes", "Total Length of Bwd Packets"),
                 ("log_orig_pkts", "Total Fwd Packets"), ("log_resp_pkts", "Total Backward Packets")]:
        df[a] = np.log1p(pd.to_numeric(df[b], errors="coerce").clip(lower=0))
    df["pkt_rate_ratio"] = df["Total Fwd Packets"] / (df["Total Backward Packets"] + 1)
    df["bytes_per_pkt"] = df["Total Length of Fwd Packets"] / df["Total Fwd Packets"].replace(0, np.nan)
    df["payload_entropy"] = df["Payload Prefix"].fillna("").map(shannon_entropy_hex)
    df["dst_port_b"] = df["Destination Port"]
    return df


def build_pipeline(seed=0):
    ct = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), NUM),
        ("cat", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=20), CAT),
        ("port", FunctionTransformer(bucket_port, validate=False), ["dst_port_b"]),
    ], sparse_threshold=0)
    return Pipeline([("clean", FunctionTransformer(clean_raw, validate=False)), ("features", ct),
                     ("rf", RandomForestClassifier(n_estimators=150, min_samples_leaf=2, class_weight="balanced", n_jobs=-1, random_state=seed))])


def raw_timestamps(raw):
    """Parse the export timestamps for splitting. Not a model feature."""
    col = [c for c in raw.columns if c.strip() == "Timestamp"][0]
    return pd.Series(parse_12h_monotonic(raw[col]), index=raw.index)


def labels_for_raw(raw, tickets):
    """Join tickets to the raw export on exporter Flow ID plus UTC second."""
    fid = [c for c in raw.columns if c.strip() == "Flow ID"][0]
    key = pd.DataFrame({"export_flow_id": raw[fid].values, "export_ts_utc": raw_timestamps(raw).dt.strftime("%Y-%m-%dT%H:%M:%SZ").values})
    t = tickets[["export_flow_id", "export_ts_utc"]].drop_duplicates().assign(label=1)
    return key.merge(t, on=["export_flow_id", "export_ts_utc"], how="left")["label"].fillna(0).astype(int).values


def split_indices(raw, how="time_gap", test_frac=0.2, gap_minutes=10, seed=0):
    ts = raw_timestamps(raw)
    n = len(raw)
    if how == "random":
        rng = np.random.default_rng(seed)
        perm = rng.permutation(n); cut = int(n * (1 - test_frac))
        return np.sort(perm[:cut]), np.sort(perm[cut:])
    order = np.argsort(ts.values, kind="stable")
    cut = int(n * (1 - test_frac))
    tr, te = order[:cut], order[cut:]
    if how == "time_gap":
        boundary = ts.iloc[te[0]]
        tr = tr[(ts.iloc[tr] < boundary - pd.Timedelta(minutes=gap_minutes)).values]
    return np.sort(tr), np.sort(te)


def leakage_checks(raw, tr, te, pipe):
    ts = raw_timestamps(raw)
    fid = [c for c in raw.columns if c.strip() == "Flow ID"][0]
    src = [c for c in raw.columns if c.strip() == "Source IP"][0]; dst = [c for c in raw.columns if c.strip() == "Destination IP"][0]
    dport = [c for c in raw.columns if c.strip() == "Destination Port"][0]
    checks = {}
    checks["train_before_test"] = bool(ts.iloc[tr].max() < ts.iloc[te].min())
    rh = pd.util.hash_pandas_object(raw, index=False)
    checks["no_identical_rows_across_split"] = not bool(set(rh.iloc[tr]) & set(rh.iloc[te]))
    sess = raw[src].astype(str) + "|" + raw[dst].astype(str) + "|" + raw[dport].astype(str) + "|" + ts.dt.floor("10min").astype(str)
    checks["no_session_overlap"] = not bool(set(sess.iloc[tr]) & set(sess.iloc[te]))
    sc = pipe.named_steps["features"].named_transformers_["num"].named_steps["sc"]
    tr_num = clean_raw(raw.iloc[tr])[NUM].median()  # imputer median then scaler mean is on train rows only
    checks["scaler_fit_on_train_only"] = bool(np.allclose(sc.n_samples_seen_, len(tr)))
    return checks


def shuffle_check(raw, tr, y, seed=0):
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import average_precision_score
    ys = np.random.default_rng(seed).permutation(y[tr])
    a, b = train_test_split(np.arange(len(tr)), test_size=0.3, random_state=seed)
    p = build_pipeline(seed).fit(raw.iloc[tr[a]], ys[a]).predict_proba(raw.iloc[tr[b]])[:, 1]
    return float(average_precision_score(ys[b], p))


def write_artefact(pipe, raw, tr, out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "feature_pipeline.joblib"
    joblib.dump(pipe, path)
    fid = [c for c in raw.columns if c.strip() == "Flow ID"][0]
    rows = hashlib.sha256("\n".join(sorted(raw[fid].iloc[tr].astype(str))).encode()).hexdigest()
    schema = {"input_columns": [c.strip() for c in raw.columns], "input_dtypes": {c.strip(): str(t) for c, t in raw.dtypes.items()},
              "sklearn": sklearn.__version__, "pandas": pd.__version__, "numpy": np.__version__, "python": platform.python_version(),
              "train_rows": int(len(tr)), "train_row_merkle": rows, "artefact_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "warning": "joblib artefacts are pickles. Loading one executes code. Verify the hash before load (Module 7)."}
    (out_dir / "schema.json").write_text(json.dumps(schema, indent=1))
    return path, schema


if __name__ == "__main__":
    from common import W1
    raw = pd.read_csv(W1 / "flows_export.csv", low_memory=False)
    y = labels_for_raw(raw, pd.read_csv(W1 / "tickets.csv"))
    state = {"raw": raw, "y": y}
    for how in ["random", "time", "time_gap"]:
        tr, te = split_indices(raw, how)
        pipe = build_pipeline().fit(raw.iloc[tr], y[tr])
        from sklearn.metrics import average_precision_score
        print(how, round(average_precision_score(y[te], pipe.predict_proba(raw.iloc[te])[:, 1]), 3), leakage_checks(raw, tr, te, pipe))
    print("shuffle", shuffle_check(raw, tr, y))
    print(write_artefact(pipe, raw, tr, "/tmp/lab3_out")[1]["artefact_sha256"][:12])
