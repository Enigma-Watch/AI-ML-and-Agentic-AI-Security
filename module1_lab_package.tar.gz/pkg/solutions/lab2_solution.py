"""Lab 2 reference solution. Populates `state` for every step so run_lab.py can probe it."""
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs"):
    sys.path.insert(0, str(p))
from common import W1  # noqa: E402
import lab2_tools as T  # noqa: E402

state = {"df": pd.read_pickle(W1 / "lab2_table.pkl")}

# Step 1: the data scientist's spec, everything in
FULL = {"numeric": ["duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "bytes_per_pkt", "payload_entropy",
                    "orig_ttl", "host_alert_count_24h"],
        "categorical": {"proto": "onehot", "service": "onehot", "conn_state": "onehot", "history": "onehot", "dst_port": "onehot",
                        "source_sensor": "onehot", "ticket_id": "onehot"},
        "text": ["analyst_note", "cmdline_window"]}

# Step 3: decisions. The honest set below is what survives.
state["decisions"] = {
    "ticket_id": {"action": "drop", "reason": "label leakage: populated only for positives"},
    "analyst_note": {"action": "drop", "reason": "label leakage: written by the people who assigned the label"},
    "raised_by": {"action": "drop", "reason": "label leakage: an analyst name exists only where a ticket exists"},
    "department": {"action": "drop", "reason": "proxy leakage: 'unmanaged' means absent from the CMDB, which is the red-team box"},
    "criticality": {"action": "keep", "reason": "legitimate asset context, present for every managed host"},
    "orig_ttl": {"action": "drop", "reason": "proxy leakage: TTL identifies the red-team host OS, not the behaviour"},
    "host_alert_count_24h": {"action": "drop", "reason": "temporal leakage: centred window counts tickets raised after the flow"},
    "cmdline_window": {"action": "drop", "reason": "temporal leakage via symmetric join: captures IR containment commands"},
    "source_sensor": {"action": "drop", "reason": "proxy leakage: sensor-B tapped the segment the red team sat on"},
    "dst_port": {"action": "transform", "reason": "distribution artefact: bucket to port class plus admin-port flag"},
    "history": {"action": "keep", "reason": "genuine signal: SYN-only and abrupt-close shapes are the traffic, not the label"},
    "conn_state": {"action": "keep", "reason": "genuine signal"},
    "duration": {"action": "keep", "reason": "behavioural"}, "orig_bytes": {"action": "keep", "reason": "behavioural"},
    "resp_bytes": {"action": "keep", "reason": "behavioural"}, "orig_pkts": {"action": "keep", "reason": "behavioural"},
    "resp_pkts": {"action": "keep", "reason": "behavioural"}, "bytes_per_pkt": {"action": "keep", "reason": "behavioural"},
    "payload_entropy": {"action": "keep", "reason": "behavioural"}, "proto": {"action": "keep", "reason": "behavioural"},
    "service": {"action": "keep", "reason": "behavioural; unknown services handled by the encoder"},
}

# Step 4: honest spec with in-pipeline encodings
HONEST = {"numeric": ["duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "bytes_per_pkt", "payload_entropy"],
          "categorical": {"proto": "onehot", "service": "onehot", "conn_state": "onehot", "history": "onehot", "dst_port": "bucket_port", "criticality": "onehot"},
          "text": []}
state["spec"] = HONEST

# Step 5: threshold and hand-computed PPV. The learner fills ppv_estimate from the confusion matrix by hand;
# here it is filled from the tool so the reference passes. Replace with your own arithmetic.
state["threshold"] = 0.5
if __name__ == "__lab__":
    import gate
    r = gate.gate_lab2(HONEST)
    state["ppv_estimate"] = T.ppv_at_threshold(r["labels"], r["scores"], 0.5)["ppv"]
