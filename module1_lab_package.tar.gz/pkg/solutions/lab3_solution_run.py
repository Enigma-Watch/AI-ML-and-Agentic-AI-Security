"""Lab 3 reference solution runner. Populates `state` for every step so run_lab.py can probe it."""
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs", ROOT / "solutions"):
    sys.path.insert(0, str(p))
from common import W1  # noqa: E402
import lab3_solution as S  # noqa: E402

raw = pd.read_csv(W1 / "flows_export.csv", low_memory=False)          # raw, untouched, exactly what the platform delivers
y = S.labels_for_raw(raw, pd.read_csv(W1 / "tickets.csv"))
tr, te = S.split_indices(raw, "time_gap")
pipe = S.build_pipeline(seed=0).fit(raw.iloc[tr], y[tr])
state = {"raw": raw, "y": y, "pipe": pipe, "split": "time_gap", "train_idx": tr, "test_idx": te}
state["checks"] = S.leakage_checks(raw, tr, te, pipe)
out = Path(ROOT / "outputs" / "lab3")
S.write_artefact(pipe, raw, tr, out)
state["artefact_dir"] = str(out)
