"""Lab 1 reference solution. Populates `state` for every step so run_lab.py can probe it."""
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src"):
    sys.path.insert(0, str(p))
from common import FLOW_SCHEMA, W1  # noqa: E402
import ingest as I  # noqa: E402

state = {}

# Step 1: load with format-specific readers; never abort on a corrupt EVTX chunk
state["zeek_a"] = I.normalise_zeek(I.read_zeek_tsv(W1 / "zeek_sensorA_conn.log"), "A")
state["zeek_b"] = I.normalise_zeek(I.read_zeek_json(W1 / "zeek_sensorB_conn.jsonl"), "B")
flows = I.read_flows_csv_raw(W1 / "flows_export.csv")
state["windows"] = I.read_windows_dir(W1 / "windows")
state["parse_errors"] = state["windows"].attrs["parse_errors"]

# Step 2: schema. Infinity to NaN with a zero_duration flag; duplicate column proven equal then dropped; nothing deleted
state["flows"] = I.clean_flow_columns(flows)

# Step 3: timestamps. Per-source timezone to UTC; 12-hour export resolved by file order; local-time Windows hosts detected
state["zeek_a"]["ts_utc"] = I.zeek_ts_utc(state["zeek_a"])
state["zeek_b"]["ts_utc"] = I.zeek_ts_utc(state["zeek_b"])
state["flows"]["ts_utc"] = I.parse_12h_monotonic(state["flows"]["Timestamp"])
_tmp = pd.concat([state["zeek_a"][FLOW_SCHEMA], state["zeek_b"][FLOW_SCHEMA]])
state["windows"] = I.fix_windows_time(state["windows"], _tmp)
state["shifted_hosts"] = state["windows"].attrs["shifted_hosts"]

# Step 4: dedup on 5-tuple + bytes + time proximity, provenance carried on the survivor
state["table"] = I.dedup_flows(_tmp[FLOW_SCHEMA].reset_index(drop=True))
state["tickets"] = I.read_tickets(W1 / "tickets.csv")

if __name__ == "__main__":
    print({k: (v.shape if hasattr(v, "shape") else v) for k, v in state.items() if k != "parse_errors"})
