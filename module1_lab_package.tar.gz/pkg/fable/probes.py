"""Probes: one function per lab step. Each takes the learner's `state` dict and returns a Result.

A Result carries: ok (bool), branch (id of the feedback branch), message, metrics.
Branch ids and messages live in MESSAGES so the manifest and the probes stay in sync.
Fable (or run_lab.py) calls probe(state) after the learner submits a step and renders the branch.
"""
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs", ROOT / "solutions"):
    sys.path.insert(0, str(p))
from common import BEACON_DST, BEACON_SRC, W1, load_truth  # noqa: E402


@dataclass
class Result:
    ok: bool
    branch: str
    message: str
    metrics: dict = field(default_factory=dict)

    def __str__(self):
        head = "PASS" if self.ok else "STOP"
        m = "" if not self.metrics else "\n  metrics: " + json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in self.metrics.items()}, default=str)
        return f"[{head}] ({self.branch}) {self.message}{m}"


MESSAGES = {
    # ---------------------------------------------------------------- Lab 1
    "l1s1_missing": "One or more of state['zeek_a'], state['zeek_b'], state['flows'], state['windows'] is missing. Load all four before submitting.",
    "l1s1_fields_header": "Sensor-A loaded with the '#fields' line as data and every column typed object. Zeek TSV needs its header honoured and '-' treated as unset.",
    "l1s1_infinity_text": "Your flow rate columns contain inf (pandas parsed the literal 'Infinity') or are still text. Nothing downstream will scale, split, or train on them; StandardScaler will throw in Lab 3. Fix it here: undefined is NaN, not infinity.",
    "l1s1_evtx_abort": "One corrupt chunk killed most of a host's Security log. A collector that stops on the first bad record is a collector an attacker can silence with one malformed event. Wrap the record iterator, log the failure with the chunk offset, continue.",
    "l1s1_ok": "All four sources are in memory with sane dtypes and the corrupt chunk did not take the host with it.",
    "l1s2_no_flag": "state['flows'] has no zero_duration column. Undefined stays undefined; the flag preserves the signal.",
    "l1s2_dropped_rows": "You deleted rows from the export. {pct_attack_shaped:.0%} of them are single-packet S0/REJ flows. That is the shape of reconnaissance. The defect in the exporter's rate calculation is not a defect in the record.",
    "l1s2_zero_fill": "Rate columns are 0 where duration is 0. A one-packet flow with duration 0 has undefined rate, not zero rate. You merged two populations; Lab 2 will show this as a feature that is noisy for no reason.",
    "l1s2_dup_col": "'Fwd Header Length' still appears twice. Any tree model will split importance across them at random and your Lab 2 importance chart will lie to you. Prove they are equal, then drop one.",
    "l1s2_ok": "Schema aligned. Undefined rates are NaN with a zero_duration flag, the duplicate column is gone, nothing was deleted.",
    "l1s3_naive": "Timestamps are not timezone-aware UTC on every source. A naive timestamp is a claim with no evidence.",
    "l1s3_misaligned": "Only {align:.0%} of sensor-B rows land within 2 seconds of their sensor-A twin. Sensor-B writes local time with an offset. Until this is fixed the beacon is two interleaved series and the time split in Lab 3 will interleave sensors.",
    "l1s3_folded": "Your flow export parses to a range that does not match the 08:00 to 14:00 UTC capture (span {span_h:.1f} h, see metrics). Look at the raw strings: 12-hour clock, no AM/PM marker. The exporter writes in arrival order, so ordering resolves it; parsing alone cannot.",
    "l1s3_win_local": "Hosts {hosts} still report events after the capture window ended. Their SystemTime is local, not UTC. Compare each host's event span against the Zeek capture window.",
    "l1s3_ok": "All timestamps are tz-aware UTC, sensor-B aligns with sensor-A, the export spans six hours, the local-time hosts are corrected.",
    "l1s4_no_table": "state['table'] is missing.",
    "l1s4_exact_only": "{rows} rows survived. You removed the log-rotation replay. You did not remove the cross-sensor twins because uid, ts and source_sensor differ. Exact-match dedup finds only the duplicates that were never going to fool anyone.",
    "l1s4_beacon_killed": "You dropped the ephemeral source port as noise and then deduplicated. You destroyed the beacon: {beacon} of 360 heartbeat flows survive. A host repeating the same connection every 60 seconds is one of the highest-value signals in this dataset and your dedup rule called it a duplicate.",
    "l1s4_provenance": "Rows are missing source_sensor, source_file or row_hash. You cannot answer 'which sensor produced this row' anymore. If sensor-B starts feeding fabricated flows you have no way to isolate them. This is the ingestion poisoning control.",
    "l1s4_ok": "{rows} rows, beacon intact ({beacon}), twins merged with both sensors recorded on the survivor. Provenance on every row. Ready for Lab 2.",
    # ---------------------------------------------------------------- Lab 2
    "l2s1_missing": "state['spec'] and state['df'] are required.",
    "l2s1_te_full": "A column ending in _te is in your spec. target_encode_full wrote the label into that column using every row. Your cross-validation is now scoring on labels it was supposed to be blind to.",
    "l2s1_report": "Random 3-fold CV: accuracy {accuracy:.3f}, ROC-AUC {roc_auc:.3f}, PR-AUC {pr_auc:.3f}. Your model is ready for the CISO deck. Before you send it, run the label-shuffle test.",
    "l2s2_fail": "Shuffled-label PR-AUC is {shuffle:.3f}; the base rate is {base:.3f}. A model that scores above chance on random labels is reading the label from a feature. Find the feature that was built from the label.",
    "l2s2_ok": "Shuffled-label PR-AUC {shuffle:.3f} sits at the base rate. The model learns something in the labels. Now: is it learning the attack, or the labelling process?",
    "l2s3_missing": "state['decisions'] must map every column in the feature pool to {{'action': keep|drop|transform, 'reason': ...}}.",
    "l2s3_review": "Decisions reviewed. {n_wrong} need another look:\n{notes}",
    "l2s3_ok": "Every leak is out or transformed to past-only, and you kept the genuine signal. The honest week-1 number will be lower. That is the correct outcome.",
    "l2s4_te_full": "Target encoding was fitted on the full dataset before splitting. Your shuffle test passed ({shuffle:.3f}) because the encoded column was computed before you shuffled; the shuffle test catches a leak only when feature construction is rerun after shuffling. Rerun on shuffled labels and your column scores {shuffle_recomputed:.3f}: low cardinality hides it here. The same construction on src_port ({card} values) scores {demo:.3f} on random labels. The construction is the leak, not the column. Fit encoders inside the pipeline.",
    "l2s4_port_onehot": "dst_port one-hot explodes to thousands of columns; every port seen once becomes a memorised attack indicator. It works and it will not survive week 2.",
    "l2s4_port_ordinal": "Port 445 is not less than port 3389. Trees tolerate this; anything with a distance metric does not, and you reuse these features with cosine similarity in Module 3.",
    "l2s4_ok": "Encodings fitted inside the pipeline. Ports bucketed with an admin-port flag.",
    "l2s5_gate": "Week-1 CV PR-AUC {w1:.3f}. Week-2 PR-AUC {w2:.3f} (base rate {base:.4f}, {pos} positives, threshold to pass {thr:.2f}). {verdict}",
    "l2s5_ppv": "At threshold {threshold}: TP {tp}, FP {fp}, PPV {ppv:.3f}, {hours:.1f} analyst hours per true positive. Your hand-computed PPV was {yours}; {ppv_verdict}",
    # ---------------------------------------------------------------- Lab 3
    "l3s1_missing": "state['pipe'] must be an sklearn Pipeline.",
    "l3s1_no_scaler": "No StandardScaler (or equivalent) inside the pipeline. Scaling done outside the artefact is scaling the platform team will never run.",
    "l3s1_unknown_error": "OneHotEncoder is set to error on unknown categories. Silent now. The platform team gets paged at 03:00 the night a new protocol appears.",
    "l3s1_ok": "Pipeline structure accepted. Whether the cleaning is really inside it will be tested on the raw week-2 file.",
    "l3s2_missing": "state['split'], state['train_idx'], state['test_idx'], state['raw'], state['y'] are required and state['pipe'] must be fitted on the train rows.",
    "l3s2_random": "Random split: week-1 test PR-AUC {w1:.3f}. Week-2 reality: {w2:.3f}. The time split's estimate on the same data was {w1_time:.3f}. One of these numbers told you approximately the truth about the future; the other told you a story about the past. Attacks come in sessions and sessions straddle random splits.",
    "l3s2_time": "Time split: week-1 test PR-AUC {w1:.3f}. Week-2 reality: {w2:.3f}. The random split would have reported {w1_random:.3f}. Your estimate is honest. Sessions still straddle the boundary; an embargo gap fixes that.",
    "l3s2_gap": "Time split with embargo: week-1 test PR-AUC {w1:.3f}. Week-2 reality: {w2:.3f}. The random split would have reported {w1_random:.3f}.",
    "l3s2_leaky_scaler": "The scaler inside your pipeline saw {seen} rows; the train partition has {train}. Its statistics include rows the model is supposed to be blind to. Preprocessing leakage is invisible in your metrics.",
    "l3s3_missing": "state['checks'] must be a dict of named boolean assertions.",
    "l3s3_disagree": "Your assertions and the grader disagree: {diff}. An assertion that passes when the condition is false is worse than no assertion.",
    "l3s3_incomplete": "Missing assertions: {missing}. The session check matters most: the beacon is 360 rows of one session and some of them are in your test set.",
    "l3s3_ok": "All leakage guards present and independently verified. Shuffled-label PR-AUC {shuffle:.3f}.",
    "l3s4_missing": "state['artefact_dir'] must contain feature_pipeline.joblib and schema.json.",
    "l3s4_crash": "The platform team just got paged. Running your artefact on the raw week-2 export raised: {error}",
    "l3s4_nondeterministic": "Two fresh-process runs produced different predictions. Something in the pipeline is unseeded.",
    "l3s4_schema": "schema.json is missing: {missing}. In Module 7 the ML-BOM and signing steps build on this file.",
    "l3s4_ok": "Artefact ran end to end on the raw week-2 export with no manual edits. Week-2 PR-AUC {w2:.3f} (threshold {thr:.2f}). Two fresh-process runs agree (prediction hash {h}). joblib wrote a pickle: loading one executes code. Record the hash, treat the file as executable.",
}


def _msg(branch, **kw):
    return MESSAGES[branch].format(**kw)


def _has(state, *keys):
    return all(k in state and state[k] is not None for k in keys)


def _tz_ok(s):
    return isinstance(s.dtype, pd.DatetimeTZDtype)


# =============================================================================== Lab 1
def lab1_step1(state):
    if not _has(state, "zeek_a", "zeek_b", "flows", "windows"):
        return Result(False, "l1s1_missing", _msg("l1s1_missing"))
    za, zb, fl, win = state["zeek_a"], state["zeek_b"], state["flows"], state["windows"]
    tr = load_truth(W1)
    if "ts" not in za.columns or not pd.api.types.is_numeric_dtype(za["ts"]):
        return Result(False, "l1s1_fields_header", _msg("l1s1_fields_header"))
    rate = [c for c in fl.columns if c.strip() in ("Flow Bytes/s", "Flow Packets/s")]
    if any(fl[c].dtype == object or np.isinf(pd.to_numeric(fl[c], errors="coerce").fillna(0)).any() for c in rate):
        return Result(False, "l1s1_infinity_text", _msg("l1s1_infinity_text"))
    hostcol = "host" if "host" in win.columns else None
    n_corrupt = int((win[hostcol] == tr["corrupt_host"]).sum()) if hostcol else 0
    expected = tr["windows_counts"][tr["corrupt_host"]]
    if n_corrupt < 0.9 * expected:
        return Result(False, "l1s1_evtx_abort", _msg("l1s1_evtx_abort"), {"records_from_corrupt_host": n_corrupt, "expected": expected})
    return Result(True, "l1s1_ok", _msg("l1s1_ok"), {"zeek_a": len(za), "zeek_b": len(zb), "flows": len(fl), "windows": len(win)})


def lab1_step2(state):
    fl = state.get("flows")
    tr = load_truth(W1)
    if fl is None or "zero_duration" not in fl.columns:
        return Result(False, "l1s2_no_flag", _msg("l1s2_no_flag"))
    cols = [c.strip() for c in fl.columns]
    if cols.count("Fwd Header Length") > 1:
        return Result(False, "l1s2_dup_col", _msg("l1s2_dup_col"))
    if len(fl) < tr["n_flows_unique"]:
        ref = pd.read_pickle(W1 / "_reference_flows.pkl").merge(pd.read_pickle(W1 / "_flowid_map.pkl")[["flow_id", "Flow ID"]], on="flow_id")
        fidcol = [c for c in fl.columns if c.strip() == "Flow ID"]
        dropped = ref[~ref["Flow ID"].isin(fl[fidcol[0]])] if fidcol else ref.iloc[len(fl):]
        shaped = float(((dropped.duration == 0) & (dropped.orig_pkts == 1) & dropped.conn_state.isin(["S0", "REJ"])).mean()) if len(dropped) else 0.0
        return Result(False, "l1s2_dropped_rows", _msg("l1s2_dropped_rows", pct_attack_shaped=shaped),
                      {"rows": len(fl), "expected": tr["n_flows_unique"], "dropped_attack_labelled": int(dropped.label.sum())})
    dur = fl[[c for c in fl.columns if c.strip() == "Flow Duration"][0]]
    bps = fl[[c for c in fl.columns if c.strip() == "Flow Bytes/s"][0]]
    z = dur == 0
    if z.any() and (bps[z].fillna(-1) == 0).mean() > 0.5:
        return Result(False, "l1s2_zero_fill", _msg("l1s2_zero_fill"))
    return Result(True, "l1s2_ok", _msg("l1s2_ok"), {"zero_duration_rows": int(z.sum())})


def lab1_step3(state):
    za, zb, fl, win = state.get("zeek_a"), state.get("zeek_b"), state.get("flows"), state.get("windows")
    tr = load_truth(W1)
    for d in (za, zb, fl, win):
        if d is None or "ts_utc" not in d.columns or not _tz_ok(d["ts_utc"]):
            return Result(False, "l1s3_naive", _msg("l1s3_naive"))
    key = ["src_ip", "src_port", "dst_ip", "dst_port", "proto"]
    a = za.rename(columns={"id.orig_h": "src_ip", "id.orig_p": "src_port", "id.resp_h": "dst_ip", "id.resp_p": "dst_port"})
    b = zb.rename(columns={"id.orig_h": "src_ip", "id.orig_p": "src_port", "id.resp_h": "dst_ip", "id.resp_p": "dst_port"})
    m = b[key + ["orig_bytes", "ts_utc"]].merge(a[key + ["orig_bytes", "ts_utc"]], on=key + ["orig_bytes"], suffixes=("_b", "_a"))
    align = float(((m.ts_utc_b - m.ts_utc_a).dt.total_seconds().abs() <= 2).mean()) if len(m) else 0.0
    if align < 0.95:
        return Result(False, "l1s3_misaligned", _msg("l1s3_misaligned", align=align), {"aligned_fraction": align})
    span = (fl["ts_utc"].max() - fl["ts_utc"].min()).total_seconds() / 3600
    w0, w1 = pd.Timestamp(tr["window_utc"][0]), pd.Timestamp(tr["window_utc"][1])
    if span < 5.5 or fl["ts_utc"].min() < w0 - pd.Timedelta(minutes=1) or fl["ts_utc"].max() > w1 + pd.Timedelta(minutes=1):
        return Result(False, "l1s3_folded", _msg("l1s3_folded", span_h=span), {"span_hours": span, "parsed_min": str(fl["ts_utc"].min()), "parsed_max": str(fl["ts_utc"].max())})
    end = pd.Timestamp(tr["window_utc"][1]) + pd.Timedelta(minutes=15)
    bad = [h for h in tr["local_time_hosts"] if (win.loc[win["host"] == h, "ts_utc"] > end).mean() > 0.05]
    if bad:
        return Result(False, "l1s3_win_local", _msg("l1s3_win_local", hosts=bad), {"hosts": bad})
    return Result(True, "l1s3_ok", _msg("l1s3_ok"), {"aligned_fraction": align, "span_hours": span})


def lab1_step4(state):
    t = state.get("table")
    tr = load_truth(W1)
    if t is None:
        return Result(False, "l1s4_no_table", _msg("l1s4_no_table"))
    n = len(t)
    beacon = int(((t["src_ip"] == BEACON_SRC) & (t["dst_ip"] == BEACON_DST)).sum())
    if n > tr["n_flows_unique"] * 1.02:
        return Result(False, "l1s4_exact_only", _msg("l1s4_exact_only", rows=n), {"rows": n, "expected": tr["n_flows_unique"]})
    if beacon < 355:
        return Result(False, "l1s4_beacon_killed", _msg("l1s4_beacon_killed", beacon=beacon), {"beacon_rows": beacon})
    prov = all(c in t.columns and t[c].notna().all() for c in ("source_sensor", "source_file", "row_hash"))
    both = t["source_sensor"].astype(str).str.contains(r"\+").sum() if "source_sensor" in t.columns else 0
    if not prov or both < 0.9 * tr["n_sensor_b"]:
        return Result(False, "l1s4_provenance", _msg("l1s4_provenance"), {"rows_with_both_sensors": int(both), "expected": tr["n_sensor_b"]})
    return Result(True, "l1s4_ok", _msg("l1s4_ok", rows=n, beacon=beacon), {"rows": n, "beacon_rows": beacon, "twins_merged": int(both)})


# =============================================================================== Lab 2
POOL = ["duration", "orig_bytes", "resp_bytes", "orig_pkts", "resp_pkts", "bytes_per_pkt", "payload_entropy", "orig_ttl",
        "host_alert_count_24h", "proto", "service", "conn_state", "history", "dst_port", "source_sensor", "ticket_id",
        "analyst_note", "cmdline_window"]
LEAKS = {"ticket_id": "label", "analyst_note": "label", "orig_ttl": "proxy (identifies the source host OS, not the behaviour)",
         "host_alert_count_24h": "temporal (centred window includes future tickets)",
         "cmdline_window": "temporal via join (symmetric window captures IR containment)",
         "source_sensor": "proxy (sensor-B tapped the segment the red team sat on)",
         "dst_port": "distribution artefact (week-2 red team hits different ports)"}
KEEP = ["history", "conn_state"]


def _spec_cols(spec):
    import lab2_tools as T
    return T.spec_columns(spec)


def lab2_step1(state):
    import lab2_tools as T
    if not _has(state, "spec", "df"):
        return Result(False, "l2s1_missing", _msg("l2s1_missing"))
    if any(c.endswith("_te") for c in _spec_cols(state["spec"])):
        return Result(False, "l2s1_te_full", _msg("l2s1_te_full"))
    r = T.quick_eval(state["df"], state["spec"], n_splits=3, n_estimators=60)
    state["w1_cv"] = r
    return Result(True, "l2s1_report", _msg("l2s1_report", **r), r)


def lab2_step2(state):
    import lab2_tools as T
    if not _has(state, "spec", "df"):
        return Result(False, "l2s1_missing", _msg("l2s1_missing"))
    s = T.shuffle_test(state["df"], state["spec"]); base = float(state["df"]["label"].mean())
    state["shuffle_pr_auc"] = s
    if s > max(0.05, 5 * base):
        return Result(False, "l2s2_fail", _msg("l2s2_fail", shuffle=s, base=base), {"shuffle_pr_auc": s})
    return Result(True, "l2s2_ok", _msg("l2s2_ok", shuffle=s), {"shuffle_pr_auc": s})


def lab2_step3(state):
    d = state.get("decisions")
    if not isinstance(d, dict) or any(c not in d for c in POOL):
        return Result(False, "l2s3_missing", _msg("l2s3_missing"), {"missing": [c for c in POOL if not d or c not in d]})
    notes = []
    for col, why in LEAKS.items():
        act = d[col].get("action")
        if col == "cmdline_window" and act == "transform":
            continue
        if col == "host_alert_count_24h" and act == "transform":
            continue
        if col == "dst_port" and act == "transform":
            continue
        if act == "keep":
            notes.append(f"  {col}: kept. Leak type: {why}.")
    for col in KEEP:
        if d[col].get("action") == "drop":
            notes.append(f"  {col}: dropped. Explain what in a SYN-only flow is an artefact of labelling rather than of the traffic. If you cannot, restore it.")
    if notes:
        return Result(False, "l2s3_review", _msg("l2s3_review", n_wrong=len(notes), notes="\n".join(notes)), {"issues": len(notes)})
    return Result(True, "l2s3_ok", _msg("l2s3_ok"))


def lab2_step4(state):
    import lab2_tools as T
    spec = state.get("spec", {})
    cats = spec.get("categorical", {})
    te_cols = [c for c in _spec_cols(spec) if c.endswith("_te")]
    if te_cols:
        s = T.shuffle_test(state["df"], spec)
        d = state["df"].copy(); d["label"] = np.random.default_rng(0).permutation(d["label"].values)
        for c in te_cols:
            T.target_encode_full(d, c[:-3])
        s2 = T.quick_eval(d, spec, n_splits=3, n_estimators=60)["pr_auc"]
        T.target_encode_full(d, "src_port")
        demo = T.quick_eval(d, {"numeric": ["src_port_te"], "categorical": {}, "text": []}, n_splits=3, n_estimators=60)["pr_auc"]
        return Result(False, "l2s4_te_full", _msg("l2s4_te_full", shuffle=s, shuffle_recomputed=s2, card=int(d["src_port"].nunique()), demo=demo),
                      {"shuffle_pr_auc": s, "shuffle_recomputed_pr_auc": s2, "src_port_full_fit_on_random_labels": demo})
    if cats.get("dst_port") == "onehot":
        return Result(False, "l2s4_port_onehot", _msg("l2s4_port_onehot"))
    if cats.get("dst_port") == "ordinal":
        return Result(False, "l2s4_port_ordinal", _msg("l2s4_port_ordinal"))
    return Result(True, "l2s4_ok", _msg("l2s4_ok"), {"encodings": cats})


def lab2_step5(state):
    import gate
    import lab2_tools as T
    r = gate.gate_lab2(state["spec"])
    thr = gate.thresholds()["lab2_w2_pr_auc"]
    w1 = state.get("w1_cv", {}).get("pr_auc", float("nan"))
    ok = r["w2_pr_auc"] >= thr
    verdict = "Passes the gate." if ok else "Below the gate. Compare ablation delta to importance rank for every remaining feature."
    msg = _msg("l2s5_gate", w1=w1, w2=r["w2_pr_auc"], base=r["w2_base_rate"], pos=r["w2_positives"], thr=thr, verdict=verdict)
    metrics = {"w1_cv_pr_auc": w1, "w2_pr_auc": r["w2_pr_auc"]}
    if "threshold" in state:
        pp = T.ppv_at_threshold(r["labels"], r["scores"], state["threshold"])
        yours = state.get("ppv_estimate")
        pv = "within one point." if yours is not None and abs(yours - pp["ppv"]) <= 0.01 else "more than one point off, or not supplied."
        msg += "\n" + _msg("l2s5_ppv", threshold=state["threshold"], tp=pp["tp"], fp=pp["fp"], ppv=pp["ppv"], hours=pp["analyst_hours_per_tp"], yours=yours, ppv_verdict=pv)
        metrics.update({k: pp[k] for k in ("tp", "fp", "ppv")})
        ok = ok and pv.startswith("within")
    return Result(ok, "l2s5_gate", msg, metrics)


# =============================================================================== Lab 3
def _find(pipe, cls):
    from sklearn.pipeline import Pipeline
    from sklearn.compose import ColumnTransformer
    out = []
    def walk(est):
        if isinstance(est, cls):
            out.append(est)
        if isinstance(est, Pipeline):
            for _, e in est.steps: walk(e)
        if isinstance(est, ColumnTransformer):
            for _, e, _ in (est.transformers_ if hasattr(est, "transformers_") else est.transformers): walk(e)
    walk(pipe)
    return out


def lab3_step1(state):
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
    p = state.get("pipe")
    if not isinstance(p, Pipeline):
        return Result(False, "l3s1_missing", _msg("l3s1_missing"))
    if not _find(p, StandardScaler):
        return Result(False, "l3s1_no_scaler", _msg("l3s1_no_scaler"))
    if any(o.handle_unknown == "error" for o in _find(p, OneHotEncoder)):
        return Result(False, "l3s1_unknown_error", _msg("l3s1_unknown_error"))
    return Result(True, "l3s1_ok", _msg("l3s1_ok"))


def lab3_step2(state):
    import gate
    import lab3_solution as S
    from sklearn.preprocessing import StandardScaler
    if not _has(state, "split", "train_idx", "test_idx", "raw", "y", "pipe"):
        return Result(False, "l3s2_missing", _msg("l3s2_missing"))
    raw, y, tr, te, pipe = state["raw"], state["y"], np.asarray(state["train_idx"]), np.asarray(state["test_idx"]), state["pipe"]
    sc = _find(pipe, StandardScaler)
    if sc and getattr(sc[0], "n_samples_seen_", None) is not None and int(np.max(sc[0].n_samples_seen_)) != len(tr):
        return Result(False, "l3s2_leaky_scaler", _msg("l3s2_leaky_scaler", seen=int(np.max(sc[0].n_samples_seen_)), train=len(tr)))
    from common import pr_auc
    w1 = pr_auc(y[te], pipe.predict_proba(raw.iloc[te])[:, 1])
    # counterfactual estimates with the learner's own pipeline structure, so the comparison is fair
    from sklearn.base import clone
    est = {}
    for how in ("random", "time"):
        a, b = S.split_indices(raw, how)
        est[how] = pr_auc(y[b], clone(pipe).fit(raw.iloc[a], y[a]).predict_proba(raw.iloc[b])[:, 1])
    ref = pd.read_pickle(gate.W2 / "_reference_flows.pkl")
    raw2 = pd.read_csv(gate.W2 / "flows_export.csv", low_memory=False)
    try:
        w2 = pr_auc(ref["label"].values, pipe.predict_proba(raw2)[:, 1])
    except Exception as e:
        w2 = float("nan"); state["_w2_error"] = str(e)[:200]
    ts = S.raw_timestamps(raw)
    ordered = bool(ts.iloc[tr].max() < ts.iloc[te].min())
    branch = "l3s2_random" if not ordered else ("l3s2_gap" if state["split"] == "time_gap" else "l3s2_time")
    m = {"w1_test_pr_auc": w1, "w2_pr_auc": w2, "estimate_random": est["random"], "estimate_time": est["time"], "train_before_test": ordered}
    return Result(ordered, branch, _msg(branch, w1=w1, w2=w2, w1_time=est["time"], w1_random=est["random"]), m)


def lab3_step3(state):
    import lab3_solution as S
    c = state.get("checks")
    if not isinstance(c, dict):
        return Result(False, "l3s3_missing", _msg("l3s3_missing"))
    tr, te = np.asarray(state["train_idx"]), np.asarray(state["test_idx"])
    truth = S.leakage_checks(state["raw"], tr, te, state["pipe"])
    need = ["train_before_test", "no_identical_rows_across_split", "no_session_overlap", "scaler_fit_on_train_only"]
    missing = [k for k in need if k not in c]
    if missing:
        return Result(False, "l3s3_incomplete", _msg("l3s3_incomplete", missing=missing), truth)
    diff = {k: (c[k], truth[k]) for k in need if bool(c[k]) != bool(truth[k])}
    if diff or not all(truth[k] for k in need):
        return Result(False, "l3s3_disagree", _msg("l3s3_disagree", diff=diff or "an assertion is False"), truth)
    s = S.shuffle_check(state["raw"], tr, state["y"])
    return Result(s < 0.05, "l3s3_ok", _msg("l3s3_ok", shuffle=s), {**truth, "shuffle_pr_auc": s})


def lab3_step4(state):
    import gate
    d = Path(state.get("artefact_dir", ""))
    art, sch = d / "feature_pipeline.joblib", d / "schema.json"
    if not (art.exists() and sch.exists()):
        return Result(False, "l3s4_missing", _msg("l3s4_missing"))
    schema = json.loads(sch.read_text())
    need = ["input_columns", "sklearn", "artefact_sha256", "train_row_merkle"]
    miss = [k for k in need if k not in schema]
    if miss:
        return Result(False, "l3s4_schema", _msg("l3s4_schema", missing=miss))
    r = gate.gate_lab3(art)
    if not r["ok"]:
        return Result(False, "l3s4_crash", _msg("l3s4_crash", error=r["error"]))
    if not r["reproducible"]:
        return Result(False, "l3s4_nondeterministic", _msg("l3s4_nondeterministic"))
    thr = gate.thresholds()["lab3_w2_pr_auc"]
    ok = r["w2_pr_auc"] >= thr
    return Result(ok, "l3s4_ok", _msg("l3s4_ok", w2=r["w2_pr_auc"], thr=thr, h=r["prediction_hash"][:12]), {"w2_pr_auc": r["w2_pr_auc"], "reproducible": True})


PROBES = {(1, 1): lab1_step1, (1, 2): lab1_step2, (1, 3): lab1_step3, (1, 4): lab1_step4,
          (2, 1): lab2_step1, (2, 2): lab2_step2, (2, 3): lab2_step3, (2, 4): lab2_step4, (2, 5): lab2_step5,
          (3, 1): lab3_step1, (3, 2): lab3_step2, (3, 3): lab3_step3, (3, 4): lab3_step4}
