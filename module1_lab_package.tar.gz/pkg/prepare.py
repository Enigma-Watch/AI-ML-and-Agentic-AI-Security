"""One-shot environment build: generate both weeks, build the Lab 2 tables, write the manifest.

  python prepare.py [--scale 1.0] [--seed 20260901] [--skip-generate]
"""
import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for p in (ROOT, ROOT / "pipeline_src", ROOT / "labs", ROOT / "fable"):
    sys.path.insert(0, str(p))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=20260901)
    ap.add_argument("--skip-generate", action="store_true")
    a = ap.parse_args()
    t = time.time()
    if not a.skip_generate:
        subprocess.run([sys.executable, str(ROOT / "generate_data.py"), "--scale", str(a.scale), "--seed", str(a.seed)], check=True)
        print(f"generated in {time.time() - t:.0f}s")
    from common import DATA, W1, W2
    import enrich, ingest
    cache = DATA / "_cache"; cache.mkdir(exist_ok=True)
    t = time.time()
    t1, w1, k1 = ingest.build_table(W1)
    l2 = enrich.build_lab2_table(t1, w1, k1)
    l2.to_pickle(cache / "lab2_w1.pkl")
    l2.to_pickle(W1 / "lab2_table.pkl")                     # what the data scientist handed to the learner
    t2, w2, k2 = ingest.build_table(W2)
    enrich.build_lab2_table(t2, w2, k2, scoring_time=True).to_pickle(cache / "lab2_w2_scoring.pkl")
    print(f"lab2 tables built in {time.time() - t:.0f}s: w1 {l2.shape}, positives {int(l2.label.sum())}")
    import manifest
    manifest.write(ROOT / "fable" / "fable_manifest.json")
    print("manifest written")


if __name__ == "__main__":
    main()
